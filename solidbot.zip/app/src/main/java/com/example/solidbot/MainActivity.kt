package com.example.solidbot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var words: EditText
    private lateinit var used: EditText
    private lateinit var pin: EditText
    private lateinit var app: EditText
    private lateinit var hh: EditText
    private lateinit var mm: EditText
    private lateinit var en: CheckBox
    private lateinit var status: TextView

    private fun et(h: String, v: String, multi: Boolean = false, type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            this.hint = h
            setText(v)
            inputType = if (multi) (type or InputType.TYPE_TEXT_FLAG_MULTI_LINE) else type
            if (multi) {
                minLines = 5
                maxLines = 8
                gravity = Gravity.TOP
            }
        }

    private fun lab(t: String) = TextView(this).apply {
        text = t
        setPadding(0, 28, 0, 4)
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { f() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val c = Cfg.p(this)
        words = et("未來學習的單字或片語，每行一個", Cfg.str(this, "words"), true)
        used = et("已經有的單字，可貼上 3000 多個", Cfg.str(this, "used"), true)
        pin = et("手機 PIN（只存在本機）", Cfg.str(this, "pin"), false,
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        app = et("App 名稱關鍵字", Cfg.str(this, "app", "SolidMemory"))
        hh = et("時 0-23", c.getInt("hour", 3).toString(), false, InputType.TYPE_CLASS_NUMBER)
        mm = et("分 0-59", c.getInt("minute", 0).toString(), false, InputType.TYPE_CLASS_NUMBER)
        en = CheckBox(this).apply {
            text = "每天自動執行"
            isChecked = c.getBoolean("enabled", false)
        }
        status = TextView(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 48)
            addView(lab("未來學習清單（每行一個單字或片語）")); addView(words)
            addView(lab("已經有的單字（程式會自動跳過）")); addView(used)
            addView(lab("手機 PIN")); addView(pin)
            addView(lab("要開啟的 App 名稱")); addView(app)
            addView(lab("每天執行時間（時 / 分）")); addView(hh); addView(mm); addView(en)
            addView(btn("儲存並套用") { save(); toast("已儲存") })
            addView(btn("① 開啟無障礙設定") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(btn("② 允許顯示在其他應用程式上層") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            addView(btn("③ 電池設定（本 App 設為不受限制）") {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            })
            addView(btn("🗂 建立詞庫（只做一次，約 3–5 小時，請充電）") {
                save()
                val b = BotService.instance
                if (b == null) toast("無障礙服務還沒開") else b.startRun("build")
            })
            addView(btn("🧪 逐步測試（按鈕、輸入、放大鏡，不改資料）") {
                save()
                val b = BotService.instance
                if (b == null) toast("無障礙服務還沒開") else b.startRun("test")
            })
            addView(btn("🔍 診斷（8 秒後讀取目前畫面）") {
                val b = BotService.instance
                if (b == null) toast("無障礙服務還沒開") else b.startRun("diag")
            })
            addView(btn("▶ 立即執行") {
                save()
                val b = BotService.instance
                if (b == null) toast("無障礙服務還沒開") else {
                    BotService.wake(this@MainActivity)
                    b.startRun()
                }
            })
            addView(btn("⏱ 1 分鐘後執行（可先鎖屏測試）") {
                save()
                Sched.at(this@MainActivity, System.currentTimeMillis() + 60000, 3)
                toast("1 分鐘後執行，現在可以鎖屏")
            })
            addView(lab("狀態與記錄")); addView(status)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun save() {
        Cfg.p(this).edit()
            .putString("words", words.text.toString())
            .putString("used", used.text.toString())
            .putString("pin", pin.text.toString())
            .putString("app", app.text.toString())
            .putInt("hour", hh.text.toString().toIntOrNull()?.coerceIn(0, 23) ?: 3)
            .putInt("minute", mm.text.toString().toIntOrNull()?.coerceIn(0, 59) ?: 0)
            .putBoolean("enabled", en.isChecked)
            .apply()
        Sched.scheduleNext(this)
    }

    override fun onResume() {
        super.onResume()
        used.setText(Cfg.str(this, "used"))
        words.setText(Cfg.str(this, "words"))
        val on = if (BotService.instance != null) "無障礙服務：已啟用" else "無障礙服務：未啟用"
        val n = Db.load(this, "db.tsv").size
        status.text = on + "\n詞庫：$n 個\n\n" + Cfg.str(this, "log")
    }

    override fun onPause() {
        super.onPause()
        save()
    }
}
