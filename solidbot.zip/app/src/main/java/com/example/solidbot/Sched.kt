package com.example.solidbot

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Sched {
    private fun op(ctx: Context, req: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, req, Intent(ctx, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun at(ctx: Context, millis: Long, req: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx, 9, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(millis, show), op(ctx, req))
    }

    fun scheduleNext(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = Cfg.p(ctx)
        if (!p.getBoolean("enabled", false)) {
            am.cancel(op(ctx, 1))
            return
        }
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, p.getInt("hour", 3))
        c.set(Calendar.MINUTE, p.getInt("minute", 0))
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 5000) c.add(Calendar.DAY_OF_YEAR, 1)
        at(ctx, c.timeInMillis, 1)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        val app = ctx.applicationContext
        Sched.scheduleNext(app)
        val pr = goAsync()
        Thread {
            try {
                BotService.wake(app)
                var n = 0
                while (BotService.instance == null && n < 30) {
                    Thread.sleep(500)
                    n++
                }
                val s = BotService.instance
                if (s != null) s.startRun() else Cfg.log(app, "無障礙服務沒開，無法執行")
            } finally {
                pr.finish()
            }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        Sched.scheduleNext(ctx.applicationContext)
    }
}
