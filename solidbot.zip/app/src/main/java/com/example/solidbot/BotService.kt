package com.example.solidbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class BotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BotService? = null
        private var wl: PowerManager.WakeLock? = null

        @Suppress("DEPRECATION")
        fun wake(ctx: Context, minutes: Int = 20) {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            releaseWake()
            wl = pm.newWakeLock(
                PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "solidbot:run"
            ).also { it.acquire(minutes * 60 * 1000L) }
        }

        fun releaseWake() {
            try {
                wl?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
            wl = null
        }
    }

    // 以 1080x2340 截圖量度的按鈕位置（讀不到文字時的備用）
    private val pos = mapOf(
        "vocab" to (275f / 1080 to 2005f / 2340),
        "input" to (300f / 1080 to 885f / 2340),
        "practice" to (779f / 1080 to 885f / 2340),
        "manage" to (300f / 1080 to 1080f / 2340),
        "clear" to (540f / 1080 to 733f / 2340),
        "add" to (893f / 1080 to 733f / 2340),
        "search" to (981f / 1080 to 434f / 2340),
        "back" to (995f / 1080 to 175f / 2340),
        "next" to (540f / 1080 to 318f / 2340)
    )
    private val blank = "_＿-–—﹍"
    private val dupWords = listOf("重複", "已存在", "已經存在", "已有", "duplicate", "exist")
    private val counterRe = Regex("數\\s*[:：]\\s*(\\d+)\\s*/\\s*(\\d+)")
    private val cjkRe = Regex("[\\u4e00-\\u9fff]+")
    private val uiChunks = setOf("下一個", "按輸入鍵", "忘記了", "刪除", "前往")
    private val wordRe = Regex("^[A-Za-z][A-Za-z '’-]*$")

    @Volatile
    private var running = false
    private var gestureFails = 0

    private fun gestureOk() = gestureFails < 3

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun startRun(mode: String = "daily") {
        if (running) return
        running = true
        Thread {
            try {
                if (mode == "build") wake(this, 360)
                doRun(mode)
            } catch (e: Throwable) {
                log("錯誤：$e")
            } finally {
                running = false
                releaseWake()
            }
        }.start()
    }

    private fun log(m: String) = Cfg.log(this, m)

    // ---------- 讀取畫面 ----------
    private fun txt(n: AccessibilityNodeInfo): String =
        (n.text?.toString()?.takeIf { it.isNotBlank() } ?: n.contentDescription?.toString() ?: "").trim()

    private fun flat(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) flat(n.getChild(i), out)
    }

    private fun appNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        flat(rootInActiveWindow, o)
        return o
    }

    private fun allNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) flat(w.root, o)
        } catch (_: Exception) {
        }
        if (o.isEmpty()) flat(rootInActiveWindow, o)
        return o
    }

    private fun imeNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) flat(w.root, o)
        } catch (_: Exception) {
        }
        return o
    }

    private fun editField(): AccessibilityNodeInfo? = appNodes().firstOrNull { it.isEditable }

    private fun cjk(ns: List<AccessibilityNodeInfo>): Set<String> {
        val o = HashSet<String>()
        for (n in ns) for (m in cjkRe.findAll(txt(n))) if (m.value !in uiChunks) o.add(m.value)
        return o
    }

    // ---------- 操作 ----------
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun gesture(g: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }
        dispatchGesture(g, cb, null)
        latch.await(3, TimeUnit.SECONDS)
        if (ok) gestureFails = 0 else gestureFails++
        return ok
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        return gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build())
    }

    private fun tapRatio(k: String) {
        val (rx, ry) = pos[k]!!
        val (w, h) = screenSize()
        tap(rx * w, ry * h)
    }

    private fun swipe(y1: Float, y2: Float, ms: Long) {
        val (w, h) = screenSize()
        val p = Path()
        p.moveTo(w / 2f, h * y1)
        p.lineTo(w / 2f, h * y2)
        gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build())
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {  // ACTION_CLICK（含往上找可點的父層）
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
        }
        return false
    }

    private fun tapNode(n: AccessibilityNodeInfo): Boolean {  // 在節點中心做真實觸控
        val r = Rect()
        n.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        if (gestureOk() && tapNode(n)) return true
        return clickNode(n)
    }

    private fun waitNode(timeout: Long, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            val n = appNodes().firstOrNull(pred)
            if (n != null) return n
            Thread.sleep(400)
        }
        return null
    }

    private fun clickText(t: String, fb: String, timeout: Long = 8000) {
        val n = waitNode(timeout) { txt(it) == t }
        if (n != null) click(n) else {
            log("找不到「$t」，改用座標點擊")
            tapRatio(fb)
        }
    }

    private fun promoShown(): Boolean = appNodes().any {
        val t = txt(it)
        t.contains("學生獎勵計劃") || t.contains("突破之旅") || t.contains("僅限學校用戶")
    }

    // 新加坡旅行彈窗：點旁邊灰色區域，不行再按返回
    private fun closePromo() {
        if (!promoShown()) return
        val (w, h) = screenSize()
        log("關閉彈窗")
        for (i in 1..3) {
            when (i) {
                1 -> tap(w / 2f, h * 0.25f)
                2 -> tap(w / 2f, h * 0.18f)
                else -> performGlobalAction(GLOBAL_ACTION_BACK)
            }
            Thread.sleep(900)
            if (!promoShown()) return
        }
    }

    // 點按鈕並確認真的進到下一頁（出現 expect 文字）；依序換方法重試
    private fun clickUntil(label: String, expect: String, fb: String, scroll: Boolean = false): Boolean {
        for (m in 0..3) {
            var n = waitNode(if (m == 0) 15000L else 3000L) { txt(it) == label }
            if (n == null && scroll) {
                for (i in 0..8) {
                    swipe(0.80f, 0.35f, 400)
                    Thread.sleep(700)
                    n = appNodes().firstOrNull { txt(it) == label }
                    if (n != null) break
                }
            }
            when (m) {
                0 -> if (n != null) { if (gestureOk()) tapNode(n) else clickNode(n) }
                1 -> if (n != null) clickNode(n)
                2 -> tapRatio(fb)
                else -> {
                    closePromo()
                    if (n != null) tapNode(n)
                }
            }
            Thread.sleep(1500)
            if (waitNode(3000L) { txt(it).contains(expect) } != null) return true
            closePromo()
        }
        log("點「$label」後沒有進到下一頁")
        return false
    }

    // 往下滑直到看到按鈕（輸入頁要滑到最底才看得到「做練習」）
    private fun clickTextScroll(t: String, fb: String) {
        for (i in 0..8) {
            val n = appNodes().firstOrNull { txt(it) == t }
            if (n != null) {
                click(n)
                return
            }
            swipe(0.80f, 0.35f, 400)
            Thread.sleep(700)
        }
        log("滑不到「$t」，改用座標點擊")
        tapRatio(fb)
    }

    private fun tapNext() {
        val n = appNodes().firstOrNull { txt(it).contains("下一個") }
        if (n != null) click(n) else tapRatio("next")
    }

    private fun setText(n: AccessibilityNodeInfo, s: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    // ---------- 解鎖 ----------
    private fun clickDigit(d: Char): Boolean {
        val s = d.toString()
        val n = allNodes().firstOrNull {
            val t = txt(it)
            t == s || t.lineSequence().firstOrNull() == s
        } ?: return false
        return click(n)
    }

    private fun unlock(km: KeyguardManager): Boolean {
        if (!km.isKeyguardLocked) return true
        val pin = Cfg.str(this, "pin")
        if (pin.isBlank()) {
            log("手機鎖著，但沒設定 PIN")
            return false
        }
        for (i in 1..3) {
            if (i == 2) {
                swipe(0.85f, 0.25f, 350)  // 第 2 次改用滑動
            } else {
                startActivity(Intent(this, UnlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Thread.sleep(2200)
            log("鎖屏畫面節點數 ${allNodes().size}（第 $i 次）")
            var okAll = true
            for (d in pin) {
                if (!clickDigit(d)) {
                    okAll = false
                    break
                }
                Thread.sleep(250)
            }
            if (!okAll) {
                log("找不到 PIN 數字鍵（第 $i 次）")
                continue
            }
            Thread.sleep(500)
            val enter = allNodes().firstOrNull { txt(it) in listOf("確認", "確定", "OK", "Enter", "Done", "輸入") }
            if (enter != null) click(enter)
            Thread.sleep(2000)
            if (!km.isKeyguardLocked) {
                log("已解鎖")
                return true
            }
        }
        return false
    }

    // 診斷：看看服務到底讀得到什麼、手勢能不能用
    private fun diag() {
        log("診斷：8 秒後讀取目前畫面，請現在切到 SolidMemory")
        Thread.sleep(8000)
        val ns = appNodes()
        log("目前視窗 ${rootInActiveWindow?.packageName}，節點 ${ns.size}，全部視窗節點 ${allNodes().size}")
        val tops = ns.filter { txt(it).isNotEmpty() }.take(30)
        log("文字：" + tops.joinToString(" | ") { txt(it).take(12) + (if (it.isClickable) "*" else "") })
        gestureFails = 0
        swipe(0.6f, 0.5f, 300)
        log("手勢測試：" + (if (gestureFails == 0) "成功" else "失敗"))
    }

    @Suppress("DEPRECATION")
    private fun launchApp(): String? {
        val key = Cfg.str(this, "app").ifBlank { "SolidMemory" }
        val pm = packageManager
        val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(key, true) }
        if (ri == null) {
            log("找不到名稱含「$key」的 App")
            return null
        }
        val pkg = ri.activityInfo.packageName
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(pkg, ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        val end = System.currentTimeMillis() + 20000
        while (System.currentTimeMillis() < end) {
            if (rootInActiveWindow?.packageName?.toString() == pkg) {
                Thread.sleep(1500)
                return pkg
            }
            Thread.sleep(500)
        }
        log("App 沒有開起來（可能被背景啟動限制擋住，請確認已允許「顯示在其他應用程式上層」）")
        return null
    }

    // ---------- 建立舊詞庫（只需做一次）----------
    private fun wordRowsFrom(ns: List<AccessibilityNodeInfo>): List<Pair<String, AccessibilityNodeInfo>> {
        val (w, h) = screenSize()
        val tmp = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
        for (n in ns) {
            val t = txt(n)
            if (!wordRe.matches(t)) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.centerY() < h * 0.13 || r.centerY() > h * 0.93 || r.centerX() > w * 0.6) continue
            tmp.add(Triple(r.centerY(), t.lowercase(), n))
        }
        return tmp.sortedBy { it.first }.map { Pair(it.second, it.third) }
    }

    private fun popupOpen(): Boolean = appNodes().any { txt(it) == "忘記了" }

    private fun closePopup() {
        val (w, h) = screenSize()
        tap(w / 2f, h * 0.04f)  // 點視窗外的灰色區域
        Thread.sleep(600)
        if (popupOpen()) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            Thread.sleep(600)
        }
    }

    private val digitRe = Regex("^\\d{1,3}$")

    // 頁碼按鈕（純數字、在畫面內）
    private fun pagerNodes(ns: List<AccessibilityNodeInfo>): List<AccessibilityNodeInfo> {
        val (_, h) = screenSize()
        return ns.filter {
            if (!digitRe.matches(txt(it))) return@filter false
            val r = Rect()
            it.getBoundsInScreen(r)
            r.top >= h * 0.12 && r.bottom <= h * 0.95
        }
    }

    // 按頁碼列最右邊的「›」；找不到節點就點最後一個頁碼右邊約 108px
    private fun nextPage(): Boolean {
        val ns = appNodes()
        val nums = pagerNodes(ns)
        if (nums.isEmpty()) return false
        val rects = nums.map {
            val r = Rect()
            it.getBoundsInScreen(r)
            r
        }
        val y = rects.map { it.centerY() }.average().toInt()
        val maxX = rects.maxOf { it.centerX() }
        val arrow = ns.firstOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            Math.abs(r.centerY() - y) < 45 && r.centerX() > maxX + 40 && r.centerX() < maxX + 200
        }
        if (arrow != null) click(arrow) else tap(maxX + 108f, y.toFloat())
        return true
    }

    // 處理目前畫面上所有還沒記錄的單字；回傳 false = 出問題需停止
    private fun processVisibleRows(db: MutableMap<String, Set<String>>, seen: MutableSet<String>): Boolean {
        while (true) {
            val nodes = appNodes()
            val row = wordRowsFrom(nodes).firstOrNull { it.first !in db && it.first !in seen } ?: return true
            val w = row.first
            seen.add(w)
            val before = nodes.map { txt(it) }.toSet()
            click(row.second)
            Thread.sleep(1200)
            val ch = cjk(appNodes().filter { txt(it) !in before })
            if (ch.isNotEmpty()) {
                Db.append(this, "db.tsv", w, ch)
                db[w] = ch
            } else {
                log("⚠ $w 沒讀到定義")
            }
            closePopup()
            if (popupOpen()) {
                log("無法關閉詞條視窗，已停止（詞庫 ${db.size} 個，下次會接著做）")
                return false
            }
        }
    }

    private fun buildDb() {
        val db = Db.load(this, "db.tsv")
        val seen = HashSet<String>()
        log("詞庫現有 ${db.size} 個，開始建立")
        var page = 1
        var lastSig = ""
        while (page <= 400) {
            for (i in 1..4) {  // 回到本頁最上面
                swipe(0.35f, 0.85f, 300)
                Thread.sleep(300)
            }
            Thread.sleep(500)
            val sig = wordRowsFrom(appNodes()).joinToString("|") { it.first }
            if (sig.isNotEmpty() && sig == lastSig) {
                log("已到最後一頁（第 $page 頁）")
                break
            }
            if (!processVisibleRows(db, seen)) return
            var guard = 0
            while (guard < 6) {
                if (pagerNodes(appNodes()).isNotEmpty()) {  // 已捲到底，頁碼看得到了
                    if (!processVisibleRows(db, seen)) return
                    break
                }
                swipe(0.80f, 0.35f, 400)
                Thread.sleep(800)
                if (!processVisibleRows(db, seen)) return
                guard++
            }
            lastSig = sig
            if (page % 5 == 0) log("第 $page 頁完成，詞庫 ${db.size} 個")
            if (!nextPage()) {
                log("找不到下一頁按鈕，停止（詞庫 ${db.size} 個）")
                return
            }
            page++
            Thread.sleep(1800)
        }
        log("詞庫建立完成，共 ${db.size} 個")
    }

    // ---------- 輸入新詞 ----------
    private fun counter(ns: List<AccessibilityNodeInfo>): Int? {
        for (n in ns) {
            val m = counterRe.find(txt(n))
            if (m != null) return m.groupValues[1].toInt() + m.groupValues[2].toInt()
        }
        return null
    }

    private fun enterWords(pool: MutableList<String>, n: Int): Pair<List<String>, List<String>> {
        val added = ArrayList<String>()
        val dupes = ArrayList<String>()
        var dupRun = 0
        while (added.size < n && pool.isNotEmpty() && dupRun < 6) {
            val w = pool.removeAt(0)
            val before = appNodes()
            val b0 = counter(before)
            val bt = before.map { txt(it) }.toSet()
            clickText("清除", "clear", 3000)
            Thread.sleep(300)
            val f = editField()
            if (f == null) {
                log("找不到輸入框")
                break
            }
            setText(f, w)
            Thread.sleep(600)
            tapRatio("search")  // 放大鏡：顯示定義
            Thread.sleep(2200)
            val searched = appNodes()
            val chunks = cjk(searched.filter { txt(it) !in bt })
            val st = searched.map { txt(it) }.toSet()
            clickText("加入", "add", 3000)
            Thread.sleep(1200)
            val after = appNodes()
            val a0 = counter(after)
            val msg = after.map { txt(it) }.toSet() - st
            val dupMsg = msg.any { t -> dupWords.any { t.contains(it, true) } }
            val ok = if (b0 != null && a0 != null) (a0 > b0 && !dupMsg) else !dupMsg
            Cfg.addUsed(this, w)
            if (ok) {
                added.add(w)
                dupRun = 0
                if (chunks.isNotEmpty()) Db.append(this, "temp.tsv", w, chunks) else log("⚠ $w 沒讀到定義")
                log("加入 $w (${added.size}/$n)")
            } else {
                dupes.add(w)
                dupRun++
                log("$w 重複，換下一個")
            }
        }
        if (dupRun >= 6) log("連續 6 個都判定重複，可能判斷有誤，已停止")
        return Pair(added, dupes)
    }

    // ---------- 練習 ----------
    // 題目頂端的格式，例如「____d _______」（片語會有空格）
    private fun findPattern(ns: List<AccessibilityNodeInfo>): String? {
        val (_, h) = screenSize()
        val parts = ArrayList<Pair<Int, String>>()
        for (n in ns) {
            val t = txt(n).trim()
            if (t.length < 2 || t.none { it in blank }) continue
            if (!t.all { it in blank || it == ' ' || it in 'a'..'z' || it in 'A'..'Z' }) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.centerY() > h * 0.2) continue
            parts.add(Pair(r.centerX(), t))
        }
        if (parts.isEmpty()) return null
        return parts.sortedBy { it.first }.joinToString(" ") { it.second }.replace(Regex("\\s+"), " ")
    }

    // 用題目上的中文定義／例句翻譯，去詞庫找對應單字
    private fun match(chunks: Set<String>, pat: String, db: Map<String, Set<String>>): String? {
        if (chunks.isEmpty()) return null
        val groups = pat.lowercase().split(" ").filter { it.isNotEmpty() }
        var best: String? = null
        var bestScore = 0.0
        var second = 0.0
        for ((w, ch) in db) {
            val toks = w.split(" ")
            if (toks.size != groups.size) continue
            var ok = true
            for (i in toks.indices) {
                if (Math.abs(toks[i].length - groups[i].length) > 1) {
                    ok = false
                    break
                }
            }
            if (!ok) continue
            val hint = groups[0].last()
            if (hint.isLetter() && toks[0].last() != hint) continue
            val s = chunks.count { it in ch }.toDouble() / chunks.size
            if (s > bestScore) {
                second = bestScore
                bestScore = s
                best = w
            } else if (s > second) {
                second = s
            }
        }
        return if (best != null && bestScore >= 0.75 && bestScore - second >= 0.15) best else null
    }

    private fun typeAnswer(ans: String) {
        val f = editField()
        if (f != null) {
            setText(f, ans)
            return
        }
        for (c in ans) {  // 找不到輸入框 → 改點螢幕鍵盤
            val k = imeNodes().firstOrNull { txt(it).equals(c.toString(), true) }
            if (k != null) click(k)
            Thread.sleep(120)
        }
    }

    private fun submit() {
        val f = editField()
        if (f != null && Build.VERSION.SDK_INT >= 30 &&
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        ) return
        val e = imeNodes().firstOrNull { txt(it) in listOf("前往", "Go", "Enter", "完成", "搜尋") }
        if (e != null) click(e) else tapNext()
    }

    private fun practice(db: Map<String, Set<String>>) {
        var misses = 0
        var lastKey = ""
        var repeat = 0
        for (i in 1..200) {
            val items = appNodes()
            val pat = findPattern(items)
            if (pat == null) {
                misses++
                if (misses >= 3) {
                    log("練習結束")
                    return
                }
                tapNext()
                Thread.sleep(1000)
                continue
            }
            misses = 0
            val chunks = cjk(items)
            val key = pat + chunks.sorted().joinToString("")
            if (key == lastKey) repeat++ else {
                repeat = 0
                lastKey = key
            }
            val ans = if (repeat >= 2) null else match(chunks, pat, db)
            if (ans == null) {
                log("Q$i $pat 無法確定答案，跳過")
                tapNext()
                Thread.sleep(1000)
                continue
            }
            typeAnswer(ans)
            Thread.sleep(400)
            submit()
            Thread.sleep(1200)
            log("Q$i $pat → $ans")
            val after = appNodes()
            val p2 = findPattern(after)
            if (p2 == null || (p2 == pat && cjk(after) == chunks)) {
                tapNext()
                Thread.sleep(1000)
            }
        }
    }

    // ---------- 主流程 ----------
    private fun removeFromFuture(done: Set<String>) {
        val keep = Cfg.str(this, "words").lines().filter { it.trim().lowercase() !in done }
        Cfg.p(this).edit().putString("words", keep.joinToString("\n")).apply()
    }

    private fun dailyRun() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (Cfg.str(this, "lastEnter") == today) {
            log("今天已輸入過新詞，這次只做練習")
        } else {
            val old = Db.load(this, "db.tsv")
            val used = Cfg.usedSet(this)
            val pool = Cfg.wordList(this, "words").filter { it !in used && it !in old }.distinct().toMutableList()
            if (pool.isEmpty()) {
                log("沒有可用的候選單字，這次只做練習")
            } else {
                if (!clickUntil("輸入詞彙", "加入", "input")) return
                Thread.sleep(1200)
                val r = enterWords(pool, 5)
                val done = (r.first + r.second).toSet()
                if (done.isNotEmpty()) removeFromFuture(done)  // 這幾個從「未來學習」清單刪除
                if (r.first.isNotEmpty()) Cfg.p(this).edit().putString("lastEnter", today).apply()
                if (imeNodes().isNotEmpty()) {
                    performGlobalAction(GLOBAL_ACTION_BACK)  // 收起鍵盤
                    Thread.sleep(600)
                }
            }
        }
        val db = Db.load(this, "db.tsv")
        db.putAll(Db.load(this, "temp.tsv"))  // 新詞暫存，練習用
        if (db.isEmpty()) {
            log("詞庫是空的，請先按「建立詞庫」")
            return
        }
        if (!clickUntil("做練習", "下一個", "practice", true)) return  // 輸入頁要滑到最底才看到
        Thread.sleep(1800)
        practice(db)
        Db.merge(this)  // 新詞練習完 → 併入舊詞庫，暫存清空
    }

    private fun doRun(mode: String) {
        log("===== 開始（$mode）=====")
        gestureFails = 0
        if (mode == "diag") {
            diag()
            return
        }
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val wasLocked = km.isKeyguardLocked
        if (!unlock(km)) {
            log("解鎖失敗，結束")
            return
        }
        val pkg = launchApp() ?: return
        log("已開啟 $pkg")
        Thread.sleep(2000)
        closePromo()
        log("畫面節點數 ${appNodes().size}")
        if (!clickUntil("詞彙學習", "輸入詞彙", "vocab")) return
        Thread.sleep(1000)
        if (mode == "build") {
            if (!clickUntil("管理詞彙", "刪除選定", "manage")) return
            Thread.sleep(2000)
            buildDb()
        } else {
            dailyRun()
        }
        log("===== 結束 =====")
        if (wasLocked) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            Thread.sleep(800)
            if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }
}
