package com.example.solidbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class BotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BotService? = null
        private var wl: PowerManager.WakeLock? = null

        @Suppress("DEPRECATION")
        fun wake(ctx: Context, minutes: Int = 20) {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            releaseWake()
            wl = pm.newWakeLock(
                PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "solidbot:run"
            ).also { it.acquire(minutes * 60 * 1000L) }
        }

        fun releaseWake() {
            try {
                wl?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
            wl = null
        }
    }

    // 以 1080x2340 截圖量度的按鈕位置（讀不到文字時的備用）
    private val pos = mapOf(
        "vocab" to (275f / 1080 to 2005f / 2340),
        "input" to (300f / 1080 to 885f / 2340),
        "practice" to (779f / 1080 to 885f / 2340),
        "manage" to (300f / 1080 to 1080f / 2340),
        "clear" to (540f / 1080 to 733f / 2340),
        "add" to (893f / 1080 to 733f / 2340),
        "search" to (981f / 1080 to 434f / 2340),
        "back" to (995f / 1080 to 175f / 2340),
        "next" to (540f / 1080 to 318f / 2340)
    )
    private val blank = "_＿-–—﹍"
    private val dupWords = listOf("重複", "已存在", "已經存在", "已有", "duplicate", "exist")
    private val counterRe = Regex("數\\s*[:：]\\s*(\\d+)\\s*/\\s*(\\d+)")
    private val cjkRe = Regex("[\\u4e00-\\u9fff]+")
    private val uiChunks = setOf("下一個", "按輸入鍵", "忘記了", "刪除", "前往")
    private val wordRe = Regex("^[A-Za-z][A-Za-z '’-]*$")

    @Volatile
    private var running = false
    private var gestureFails = 0

    @Volatile
    private var targetPkg: String? = null

    private fun gestureOk() = gestureFails < 3

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun startRun(mode: String = "daily") {
        if (running) return
        running = true
        Thread {
            try {
                if (mode == "build") wake(this, 360)
                doRun(mode)
            } catch (e: Throwable) {
                log("錯誤：$e")
            } finally {
                running = false
                releaseWake()
            }
        }.start()
    }

    private fun log(m: String) = Cfg.log(this, m)

    // ---------- 讀取畫面 ----------
    private fun txt(n: AccessibilityNodeInfo): String =
        (n.text?.toString()?.takeIf { it.isNotBlank() } ?: n.contentDescription?.toString() ?: "").trim()

    private fun flat(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) flat(n.getChild(i), out)
    }

    private fun appNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        val tp = targetPkg
        if (tp != null) {  // 優先讀 SolidMemory 自己的視窗
            try {
                for (w in windows) {
                    if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION && w.root?.packageName?.toString() == tp) {
                        flat(w.root, o)
                        if (o.isNotEmpty()) return o
                    }
                }
            } catch (_: Exception) {
            }
        }
        val r = rootInActiveWindow
        if (r != null) {
            flat(r, o)
            return o
        }
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    flat(w.root, o)
                    if (o.isNotEmpty()) break
                }
            }
        } catch (_: Exception) {
        }
        return o
    }

    private fun topPkg(): String? {
        val r = rootInActiveWindow
        if (r != null) return r.packageName?.toString()
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    val pk = w.root?.packageName?.toString()
                    if (pk != null) return pk
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun allNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) flat(w.root, o)
        } catch (_: Exception) {
        }
        if (o.isEmpty()) flat(rootInActiveWindow, o)
        return o
    }

    private fun imeNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) flat(w.root, o)
        } catch (_: Exception) {
        }
        return o
    }

    private fun editField(): AccessibilityNodeInfo? = appNodes().firstOrNull { it.isEditable }

    private fun cjk(ns: List<AccessibilityNodeInfo>): Set<String> {
        val o = HashSet<String>()
        for (n in ns) for (m in cjkRe.findAll(txt(n))) if (m.value !in uiChunks) o.add(m.value)
        return o
    }

    // ---------- 操作 ----------
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun gesture(g: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }
        dispatchGesture(g, cb, null)
        latch.await(3, TimeUnit.SECONDS)
        if (ok) gestureFails = 0 else gestureFails++
        return ok
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        return gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 90)).build())
    }

    private fun tapRatio(k: String) {
        val (rx, ry) = pos[k]!!
        val (w, h) = screenSize()
        tap(rx * w, ry * h)
    }

    private fun swipe(y1: Float, y2: Float, ms: Long) {
        val (w, h) = screenSize()
        val p = Path()
        p.moveTo(w / 2f, h * y1)
        p.lineTo(w / 2f, h * y2)
        gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build())
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {  // ACTION_CLICK（含往上找可點的父層）
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
        }
        return false
    }

    private fun tapNode(n: AccessibilityNodeInfo, stable: Boolean = false): Boolean {  // 在節點中心做真實觸控
        val r = Rect()
        n.getBoundsInScreen(r)
        if (stable) {  // 等位置不再移動（頁面轉場動畫中按鈕會移動）
            for (i in 1..4) {
                Thread.sleep(350)
                n.refresh()
                val r2 = Rect()
                n.getBoundsInScreen(r2)
                if (r2 == r) break
                r.set(r2)
            }
        }
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        if (gestureOk() && tapNode(n)) return true
        return clickNode(n)
    }

    private fun waitNode(timeout: Long, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            val n = appNodes().firstOrNull(pred)
            if (n != null) return n
            Thread.sleep(400)
        }
        return null
    }

    private fun clickText(t: String, fb: String, timeout: Long = 8000) {
        val n = waitNode(timeout) { txt(it) == t }
        if (n != null) click(n) else {
            log("找不到「$t」，改用座標點擊")
            tapRatio(fb)
        }
    }

    private fun promoShown(): Boolean = appNodes().any {
        val t = txt(it)
        t.contains("學生獎勵計劃") || t.contains("突破之旅") || t.contains("僅限學校用戶")
    }

    // 新加坡旅行彈窗：點旁邊灰色區域，不行再按返回
    private fun closePromo() {
        if (!promoShown()) return
        val (w, h) = screenSize()
        log("關閉彈窗")
        for (i in 1..4) {
            when (i) {
                1 -> tap(w / 2f, h * 0.25f)
                2 -> tap(w / 2f, h * 0.064f)
                3 -> tap(w / 2f, h * 0.80f)
                else -> performGlobalAction(GLOBAL_ACTION_BACK)
            }
            Thread.sleep(900)
            if (!promoShown()) return
        }
    }

    // 點按鈕並確認真的進到下一頁（出現 expect 文字）；依序換方法重試
    private fun clickUntil(label: String, expect: String, fb: String, scroll: Boolean = false): Boolean {
        for (m in 0..3) {
            var n = waitNode(if (m == 0) 15000L else 3000L) { txt(it) == label }
            if (n == null && scroll) {
                for (i in 0..8) {
                    swipe(0.80f, 0.35f, 400)
                    Thread.sleep(700)
                    n = appNodes().firstOrNull { txt(it) == label }
                    if (n != null) break
                }
            }
            when (m) {
                0 -> if (n != null) { if (gestureOk()) tapNode(n, true) else clickNode(n) }
                1 -> if (n != null) clickNode(n)
                2 -> tapRatio(fb)
                else -> {
                    closePromo()
                    if (n != null) tapNode(n, true)
                }
            }
            Thread.sleep(1500)
            if (waitNode(3000L) { txt(it).contains(expect) } != null) {
                log("「$label」成功（第 ${m + 1} 種方法）")
                return true
            }
            closePromo()
        }
        log("點「$label」後沒有進到下一頁")
        return false
    }

    // 往下滑直到看到按鈕（輸入頁要滑到最底才看得到「做練習」）
    private fun clickTextScroll(t: String, fb: String) {
        for (i in 0..8) {
            val n = appNodes().firstOrNull { txt(it) == t }
            if (n != null) {
                click(n)
                return
            }
            swipe(0.80f, 0.35f, 400)
            Thread.sleep(700)
        }
        log("滑不到「$t」，改用座標點擊")
        tapRatio(fb)
    }

    private fun tapNext() {
        val n = appNodes().firstOrNull { txt(it).contains("下一個") }
        if (n != null) click(n) else tapRatio("next")
    }

    private fun setText(n: AccessibilityNodeInfo, s: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    // ---------- 解鎖 ----------
    // PIN 數字鍵：只找螢幕下半部（鎖屏的大時鐘在上半部，之前就是誤按了它）
    private fun keyNode(d: Char): AccessibilityNodeInfo? {
        val (_, h) = screenSize()
        val s = d.toString()
        return allNodes().firstOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.centerY() > h * 0.45 && (txt(it) == s || it.contentDescription?.toString() == s)
        }
    }

    private fun waitPad(ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (keyNode('5') != null && keyNode('8') != null) return true
            Thread.sleep(300)
        }
        return false
    }

    private fun unlock(km: KeyguardManager): Boolean {
        if (!km.isKeyguardLocked) return true
        val pin = Cfg.str(this, "pin")
        if (pin.isBlank()) {
            log("手機鎖著，但沒設定 PIN")
            return false
        }
        var entered = 0
        for (i in 1..6) {
            if (!km.isKeyguardLocked) return true
            if (!waitPad(300)) {  // PIN 鍵盤還沒出現 → 叫出來
                when (i % 3) {
                    1 -> swipe(0.90f, 0.30f, 450)
                    2 -> startActivity(Intent(this, UnlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    else -> swipe(0.95f, 0.20f, 600)
                }
                val shown = waitPad(3500)
                log("第 $i 次叫出 PIN 鍵盤：" + (if (shown) "成功" else "沒出現"))
                if (!shown) continue
            }
            if (entered >= 2) break  // 最多輸入 2 次，避免輸錯被鎖機
            entered++
            var ok = true
            for (d in pin) {
                val n = keyNode(d)
                if (n == null || !click(n)) {
                    ok = false
                    break
                }
                Thread.sleep(250)
            }
            if (!ok) {
                log("PIN 輸入中斷")
                continue
            }
            Thread.sleep(500)
            val enter = allNodes().firstOrNull { txt(it) in listOf("確認", "確定", "OK", "Enter", "Done", "輸入") }
            if (enter != null) click(enter)
            Thread.sleep(2000)
            if (!km.isKeyguardLocked) {
                log("已解鎖")
                return true
            }
        }
        return false
    }

    // 診斷：看看服務到底讀得到什麼、手勢能不能用
    private fun diag() {
        log("診斷：8 秒後讀取目前畫面，請現在切到 SolidMemory")
        Thread.sleep(8000)
        val ns = appNodes()
        log("最上層 App ${topPkg()}，節點 ${ns.size}，全部視窗節點 ${allNodes().size}")
        val wins = try {
            windows.joinToString(",") { "${it.type}:${it.root?.packageName ?: "?"}" }
        } catch (e: Exception) {
            "讀取失敗"
        }
        log("視窗（類型:套件）$wins")
        val tops = ns.filter { txt(it).isNotEmpty() }.take(30)
        log("文字：" + tops.joinToString(" | ") { txt(it).take(12) + (if (it.isClickable) "*" else "") })
        gestureFails = 0
        swipe(0.6f, 0.5f, 300)
        log("手勢測試：" + (if (gestureFails == 0) "成功" else "失敗"))
    }

    private fun appOpen(pkg: String): Boolean {
        if (topPkg() == pkg) return true
        return allNodes().any {
            val t = txt(it)
            t == "詞彙學習" || t.contains("透過閱讀學習")
        }
    }

    @Suppress("DEPRECATION")
    private fun launchApp(): String? {
        val key = Cfg.str(this, "app").ifBlank { "SolidMemory" }
        val pm = packageManager
        val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(key, true) }
        if (ri == null) {
            log("找不到名稱含「$key」的 App")
            return null
        }
        val pkg = ri.activityInfo.packageName
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(pkg, ri.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        targetPkg = null
        startActivity(intent)
        val t0 = System.currentTimeMillis()
        var resent = false
        while (System.currentTimeMillis() - t0 < 35000) {
            if (appOpen(pkg)) {
                targetPkg = pkg
                Thread.sleep(2500)
                return pkg
            }
            if (!resent && System.currentTimeMillis() - t0 > 12000) {
                resent = true
                log("App 還沒出現，再送一次啟動")
                startActivity(intent)
            }
            Thread.sleep(500)
        }
        log("App 沒有開起來（請確認已允許「顯示在其他應用程式上層」）")
        return null
    }

    // ---------- 建立舊詞庫（只需做一次）----------
    private fun wordRowsFrom(ns: List<AccessibilityNodeInfo>): List<Pair<String, AccessibilityNodeInfo>> {
        val (w, h) = screenSize()
        val tmp = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
        for (n in ns) {
            val t = txt(n)
            if (!wordRe.matches(t)) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.centerY() < h * 0.13 || r.centerY() > h * 0.93 || r.centerX() > w * 0.6) continue
            tmp.add(Triple(r.centerY(), t.lowercase(), n))
        }
        return tmp.sortedBy { it.first }.map { Pair(it.second, it.third) }
    }

    private fun popupOpen(): Boolean = appNodes().any { txt(it) == "忘記了" }

    private fun closePopup(): Boolean {
        val (w, h) = screenSize()
        for (i in 1..4) {
            when (i) {
                1 -> tap(w / 2f, h * 0.064f)   // 標題列的灰色區域（在視窗上方）
                2 -> tap(w * 0.9f, h * 0.07f)
                3 -> tap(w / 2f, h * 0.92f)    // 視窗下方的灰色區域
                else -> performGlobalAction(GLOBAL_ACTION_BACK)
            }
            Thread.sleep(800)
            if (!popupOpen()) return true
        }
        return false
    }

    private fun reopenManage(): Boolean {
        launchApp() ?: return false
        Thread.sleep(1500)
        closePromo()
        if (!clickUntil("詞彙學習", "輸入詞彙", "vocab")) return false
        Thread.sleep(1000)
        return clickUntil("管理詞彙", "刪除選定", "manage")
    }

    private val digitRe = Regex("^\\d{1,3}$")

    // 頁碼按鈕（純數字、在畫面內）
    private fun pagerNodes(ns: List<AccessibilityNodeInfo>): List<AccessibilityNodeInfo> {
        val (_, h) = screenSize()
        return ns.filter {
            if (!digitRe.matches(txt(it))) return@filter false
            val r = Rect()
            it.getBoundsInScreen(r)
            r.top >= h * 0.12 && r.bottom <= h * 0.95
        }
    }

    // 按頁碼列最右邊的「›」；找不到節點就點最後一個頁碼右邊約 108px
    private fun nextPage(): Boolean {
        val ns = appNodes()
        val nums = pagerNodes(ns)
        if (nums.isEmpty()) return false
        val rects = nums.map {
            val r = Rect()
            it.getBoundsInScreen(r)
            r
        }
        val y = rects.map { it.centerY() }.average().toInt()
        val maxX = rects.maxOf { it.centerX() }
        val arrow = ns.firstOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            Math.abs(r.centerY() - y) < 45 && r.centerX() > maxX + 40 && r.centerX() < maxX + 200
        }
        if (arrow != null) click(arrow) else tap(maxX + 108f, y.toFloat())
        return true
    }

    // 處理目前畫面上所有還沒記錄的單字；回傳 false = 視窗關不掉，需要重新開 App
    private fun processVisibleRows(db: MutableMap<String, Set<String>>, seen: MutableSet<String>): Boolean {
        while (true) {
            val nodes = appNodes()
            val row = wordRowsFrom(nodes).firstOrNull { it.first !in db && it.first !in seen } ?: return true
            val w = row.first
            seen.add(w)
            val before = nodes.map { txt(it) }.toSet()
            click(row.second)
            Thread.sleep(1200)
            if (!popupOpen()) {  // 沒開 → 換 ACTION_CLICK 再試一次
                clickNode(row.second)
                Thread.sleep(1200)
            }
            if (!popupOpen()) {
                log("⚠ 點不開 $w，略過")
                continue
            }
            val ch = cjk(appNodes().filter { txt(it) !in before })
            if (ch.isNotEmpty()) {
                Db.append(this, "db.tsv", w, ch)
                db[w] = ch
            } else {
                log("⚠ $w 沒讀到定義")
            }
            if (!closePopup()) {
                log("詞條視窗關不掉（詞庫 ${db.size} 個）")
                return false
            }
        }
    }

    private fun buildDb() {
        val db = Db.load(this, "db.tsv")
        val seen = HashSet<String>()
        log("詞庫現有 ${db.size} 個，開始建立")
        var page = 1
        var lastSig = ""
        var recoveries = 0
        while (page <= 400) {
            for (i in 1..4) {  // 回到本頁最上面
                swipe(0.35f, 0.85f, 300)
                Thread.sleep(300)
            }
            Thread.sleep(500)
            val sig = wordRowsFrom(appNodes()).joinToString("|") { it.first }
            if (sig.isNotEmpty() && sig == lastSig) {
                log("已到最後一頁（第 $page 頁）")
                break
            }
            var failed = !processVisibleRows(db, seen)
            var guard = 0
            while (!failed && guard < 6) {
                if (pagerNodes(appNodes()).isNotEmpty()) {  // 已捲到底，頁碼看得到了
                    failed = !processVisibleRows(db, seen)
                    break
                }
                swipe(0.80f, 0.35f, 400)
                Thread.sleep(800)
                failed = !processVisibleRows(db, seen)
                guard++
            }
            if (failed) {
                recoveries++
                if (recoveries > 5 || !reopenManage()) {
                    log("無法恢復，已停止（詞庫 ${db.size} 個，下次會接著做）")
                    return
                }
                log("已重新開啟管理詞彙，繼續（第 $recoveries 次恢復）")
                page = 1
                lastSig = ""
                continue
            }
            lastSig = sig
            if (page % 5 == 0) log("第 $page 頁完成，詞庫 ${db.size} 個")
            if (!nextPage()) {
                log("找不到下一頁按鈕，停止（詞庫 ${db.size} 個）")
                return
            }
            page++
            Thread.sleep(1800)
        }
        log("詞庫建立完成，共 ${db.size} 個")
    }

    // ---------- 輸入新詞 ----------
    private fun fieldText(f: AccessibilityNodeInfo): String {
        f.refresh()
        return f.text?.toString()?.trim() ?: ""
    }

    private fun addEnabled(): Boolean = appNodes().firstOrNull { txt(it) == "加入" }?.isEnabled == true

    // 輸入單字並確認網頁收到了（空白時「加入」是灰的，輸入後會變可按）；不行就改用貼上
    private fun typeWord(w: String): Boolean {
        val base = addEnabled()  // 輸入前「加入」是否本來就可按（若是，這個檢查就沒意義）
        var f = editField() ?: return false
        setText(f, w)
        Thread.sleep(700)
        val t1 = fieldText(f)
        val a1 = addEnabled()
        if (t1 == w && (a1 || base)) return true
        log("直接輸入未被接受（欄位「$t1」，加入可按=$a1），改用貼上")
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("w", w))
        f = editField() ?: return false
        setText(f, "")
        Thread.sleep(300)
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        f.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        Thread.sleep(800)
        f = editField() ?: return false
        val t2 = fieldText(f)
        val a2 = addEnabled()
        log("貼上結果：欄位「$t2」，加入可按=$a2")
        return t2 == w && (a2 || base)
    }

    private fun counter(ns: List<AccessibilityNodeInfo>): Int? {
        for (n in ns) {
            val m = counterRe.find(txt(n))
            if (m != null) return m.groupValues[1].toInt() + m.groupValues[2].toInt()
        }
        return null
    }

    private fun enterWords(pool: MutableList<String>, n: Int): Pair<List<String>, List<String>> {
        val added = ArrayList<String>()
        val dupes = ArrayList<String>()
        var dupRun = 0
        var typeFails = 0
        while (added.size < n && pool.isNotEmpty() && dupRun < 6) {
            val w = pool.removeAt(0)
            val before = appNodes()
            val b0 = counter(before)
            val bt = before.map { txt(it) }.toSet()
            clickText("清除", "clear", 3000)
            Thread.sleep(300)
            if (!typeWord(w)) {
                typeFails++
                log("輸入「$w」失敗（網頁沒接受文字）")
                if (typeFails >= 3) {
                    log("連續 3 次輸入失敗，停止")
                    break
                }
                continue
            }
            typeFails = 0
            tapRatio("search")  // 放大鏡：顯示定義
            Thread.sleep(2200)
            var searched = appNodes()
            var chunks = cjk(searched.filter { txt(it) !in bt })
            if (chunks.isEmpty()) {
                log("放大鏡第一次沒顯示定義，再按一次")
                tapRatio("search")
                Thread.sleep(2500)
                searched = appNodes()
                chunks = cjk(searched.filter { txt(it) !in bt })
            }
            val st = searched.map { txt(it) }.toSet()
            clickText("加入", "add", 3000)
            Thread.sleep(1200)
            val after = appNodes()
            val a0 = counter(after)
            val msg = after.map { txt(it) }.toSet() - st
            val dupMsg = msg.any { t -> dupWords.any { t.contains(it, true) } }
            val ok = if (b0 != null && a0 != null) (a0 > b0 && !dupMsg) else !dupMsg
            Cfg.addUsed(this, w)
            if (ok) {
                added.add(w)
                dupRun = 0
                if (chunks.isNotEmpty()) Db.append(this, "temp.tsv", w, chunks) else log("⚠ $w 沒讀到定義")
                log("加入 $w (${added.size}/$n)")
            } else {
                dupes.add(w)
                dupRun++
                log("$w 重複，換下一個")
            }
        }
        if (dupRun >= 6) log("連續 6 個都判定重複，可能判斷有誤，已停止")
        return Pair(added, dupes)
    }

    // ---------- 練習 ----------
    // 題目頂端的格式，例如「____d _______」（片語會有空格）
    private fun findPattern(ns: List<AccessibilityNodeInfo>): String? {
        val (_, h) = screenSize()
        val parts = ArrayList<Pair<Int, String>>()
        for (n in ns) {
            val t = txt(n).trim()
            if (t.length < 2 || t.none { it in blank }) continue
            if (!t.all { it in blank || it == ' ' || it in 'a'..'z' || it in 'A'..'Z' }) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.centerY() > h * 0.2) continue
            parts.add(Pair(r.centerX(), t))
        }
        if (parts.isEmpty()) return null
        return parts.sortedBy { it.first }.joinToString(" ") { it.second }.replace(Regex("\\s+"), " ")
    }

    // 用題目上的中文定義／例句翻譯，去詞庫找對應單字
    private fun match(chunks: Set<String>, pat: String, db: Map<String, Set<String>>): String? {
        if (chunks.isEmpty()) return null
        val groups = pat.lowercase().split(" ").filter { it.isNotEmpty() }
        var best: String? = null
        var bestScore = 0.0
        var second = 0.0
        for ((w, ch) in db) {
            val toks = w.split(" ")
            if (toks.size != groups.size) continue
            var ok = true
            for (i in toks.indices) {
                if (Math.abs(toks[i].length - groups[i].length) > 1) {
                    ok = false
                    break
                }
            }
            if (!ok) continue
            val hint = groups[0].last()
            if (hint.isLetter() && toks[0].last() != hint) continue
            val s = chunks.count { it in ch }.toDouble() / chunks.size
            if (s > bestScore) {
                second = bestScore
                bestScore = s
                best = w
            } else if (s > second) {
                second = s
            }
        }
        return if (best != null && bestScore >= 0.75 && bestScore - second >= 0.15) best else null
    }

    private fun typeAnswer(ans: String) {
        val f = editField()
        if (f != null) {
            setText(f, ans)
            return
        }
        for (c in ans) {  // 找不到輸入框 → 改點螢幕鍵盤
            val k = imeNodes().firstOrNull { txt(it).equals(c.toString(), true) }
            if (k != null) click(k)
            Thread.sleep(120)
        }
    }

    private fun submit() {
        val f = editField()
        if (f != null && Build.VERSION.SDK_INT >= 30 &&
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        ) return
        val e = imeNodes().firstOrNull { txt(it) in listOf("前往", "Go", "Enter", "完成", "搜尋") }
        if (e != null) click(e) else tapNext()
    }

    private fun practice(db: Map<String, Set<String>>) {
        var misses = 0
        var lastKey = ""
        var repeat = 0
        for (i in 1..200) {
            val items = appNodes()
            val pat = findPattern(items)
            if (pat == null) {
                misses++
                if (misses >= 3) {
                    log("練習結束")
                    return
                }
                tapNext()
                Thread.sleep(1000)
                continue
            }
            misses = 0
            val chunks = cjk(items)
            val key = pat + chunks.sorted().joinToString("")
            if (key == lastKey) repeat++ else {
                repeat = 0
                lastKey = key
            }
            val ans = if (repeat >= 2) null else match(chunks, pat, db)
            if (ans == null) {
                log("Q$i $pat 無法確定答案，跳過")
                tapNext()
                Thread.sleep(1000)
                continue
            }
            typeAnswer(ans)
            Thread.sleep(400)
            submit()
            Thread.sleep(1200)
            log("Q$i $pat → $ans")
            val after = appNodes()
            val p2 = findPattern(after)
            if (p2 == null || (p2 == pat && cjk(after) == chunks)) {
                tapNext()
                Thread.sleep(1000)
            }
        }
    }

    // ---------- 主流程 ----------
    private fun removeFromFuture(done: Set<String>) {
        val keep = Cfg.str(this, "words").lines().filter { it.trim().lowercase() !in done }
        Cfg.p(this).edit().putString("words", keep.joinToString("\n")).apply()
    }

    private fun dailyRun() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (Cfg.str(this, "lastEnter") == today) {
            log("今天已輸入過新詞，這次只做練習")
        } else {
            val old = Db.load(this, "db.tsv")
            val used = Cfg.usedSet(this)
            val pool = Cfg.wordList(this, "words").filter { it !in used && it !in old }.distinct().toMutableList()
            if (pool.isEmpty()) {
                log("沒有可用的候選單字，這次只做練習")
            } else {
                if (!clickUntil("輸入詞彙", "加入", "input")) return
                Thread.sleep(1200)
                val r = enterWords(pool, 5)
                val done = (r.first + r.second).toSet()
                if (done.isNotEmpty()) removeFromFuture(done)  // 這幾個從「未來學習」清單刪除
                if (r.first.isNotEmpty()) Cfg.p(this).edit().putString("lastEnter", today).apply()
                if (imeNodes().isNotEmpty()) {
                    performGlobalAction(GLOBAL_ACTION_BACK)  // 收起鍵盤
                    Thread.sleep(600)
                }
            }
        }
        val db = Db.load(this, "db.tsv")
        db.putAll(Db.load(this, "temp.tsv"))  // 新詞暫存，練習用
        if (db.isEmpty()) {
            log("詞庫是空的，請先按「建立詞庫」")
            return
        }
        if (!clickUntil("做練習", "下一個", "practice", true)) return  // 輸入頁要滑到最底才看到
        Thread.sleep(1800)
        practice(db)
        Db.merge(this)  // 新詞練習完 → 併入舊詞庫，暫存清空
    }

    private fun report(step: String, ok: Boolean, extra: String = "") =
        log((if (ok) "✔ " else "✘ ") + step + (if (extra.isNotEmpty()) "：$extra" else ""))

    // 逐步測試：每個動作都回報成功或失敗，不會按「加入」，不改任何資料
    private fun selfTest() {
        report("開啟 App、關彈窗、進入「詞彙學習」", true)
        val inp = clickUntil("輸入詞彙", "加入", "input")
        report("按「輸入詞彙」", inp)
        if (!inp) return
        Thread.sleep(1000)
        clickText("清除", "clear", 3000)
        Thread.sleep(300)
        report("輸入單字，網頁有接受", typeWord("test"))
        val bt = appNodes().map { txt(it) }.toSet()
        tapRatio("search")
        Thread.sleep(2500)
        val ch = cjk(appNodes().filter { txt(it) !in bt })
        report("按放大鏡，讀到定義", ch.isNotEmpty(), "新出現中文 ${ch.size} 段")
        clickText("清除", "clear", 3000)
        Thread.sleep(500)
        val f = editField()
        report("按「清除」", f != null && fieldText(f).isEmpty())
        if (imeNodes().isNotEmpty()) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            Thread.sleep(600)
        }
        val pr = clickUntil("做練習", "下一個", "practice", true)
        report("滑到底按「做練習」進入練習畫面", pr)
        if (pr) {
            Thread.sleep(1500)
            val items = appNodes()
            val pat = findPattern(items)
            report("讀到題目格式", pat != null, pat ?: "")
            report("讀到題目的中文定義", cjk(items).isNotEmpty(), "${cjk(items).size} 段")
        }
    }

    private fun doRun(mode: String) {
        log("===== 開始（$mode）=====")
        gestureFails = 0
        targetPkg = null
        if (mode == "diag") {
            diag()
            return
        }
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val wasLocked = km.isKeyguardLocked
        if (!unlock(km)) {
            log("解鎖失敗，結束")
            return
        }
        val pkg = launchApp() ?: return
        log("已開啟 $pkg")
        for (i in 1..6) {  // 彈窗可能延遲出現，持續檢查幾秒
            Thread.sleep(1000)
            closePromo()
        }
        log("畫面節點數 ${appNodes().size}")
        if (!clickUntil("詞彙學習", "輸入詞彙", "vocab")) return
        Thread.sleep(1000)
        if (mode == "build") {
            if (!clickUntil("管理詞彙", "刪除選定", "manage")) return
            Thread.sleep(2000)
            buildDb()
        } else if (mode == "test") {
            selfTest()
        } else {
            dailyRun()
        }
        log("===== 結束 =====")
        if (wasLocked) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            Thread.sleep(800)
            if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }
}
