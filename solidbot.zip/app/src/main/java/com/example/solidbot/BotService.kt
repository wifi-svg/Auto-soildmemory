package com.example.solidbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.Display
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class BotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BotService? = null
        private var wl: PowerManager.WakeLock? = null

        @Suppress("DEPRECATION")
        fun wake(ctx: Context, minutes: Int = 90) {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            releaseWake()
            wl = pm.newWakeLock(
                PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "solidbot:run"
            ).also { it.acquire(minutes * 60 * 1000L) }
        }

        fun releaseWake() {
            try {
                wl?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
            wl = null
        }
    }

    // 以 1080x2340 截圖量度的按鈕位置（讀不到文字時的備用）
    private val pos = mapOf(
        "vocab" to (275f / 1080 to 2005f / 2340),
        "input" to (300f / 1080 to 885f / 2340),
        "practice" to (779f / 1080 to 885f / 2340),
        "manage" to (300f / 1080 to 1080f / 2340),
        "clear" to (540f / 1080 to 733f / 2340),
        "add" to (893f / 1080 to 733f / 2340),
        "search" to (981f / 1080 to 434f / 2340),
        "back" to (995f / 1080 to 175f / 2340),
        "next" to (540f / 1080 to 318f / 2340),
        "label" to (100f / 1080 to 353f / 2340)
    )
    private val blank = "_＿-–—﹍"
    private val dupWords = listOf("重複", "已存在", "已經存在", "已有", "duplicate", "exist")
    private val counterRe = Regex("數\\s*[:：]\\s*(\\d+)\\s*/\\s*(\\d+)")
    private val cjkRe = Regex("[\\u4e00-\\u9fff]+")
    private val uiChunks = setOf("下一個", "按輸入鍵", "忘記了", "刪除", "前往", "英式", "美式")
    private val wordRe = Regex("^(?=.*[A-Za-z])[A-Za-z0-9][A-Za-z0-9 .'’&/-]*$")
    private val plainRe = Regex("^[A-Za-z][A-Za-z '’-]*$")

    @Volatile
    private var running = false
    private var gestureFails = 0

    @Volatile
    private var targetPkg: String? = null

    private fun gestureOk() = gestureFails < 3

    // ---------- 停止功能 ----------
    @Volatile
    private var stopFlag = false
    private var volCount = 0
    private var lastVol = 0L
    private var lastInfo = ""
    private var lastBestWord: String? = null
    private var typeLogged = false

    private class StopRun : RuntimeException()

    fun stopRun() {
        stopFlag = true
        log("收到停止指令")
    }

    private fun nap(ms: Long) {
        var left = ms
        while (left > 0) {
            if (stopFlag) throw StopRun()
            val c = if (left < 200) left else 200L
            Thread.sleep(c)
            left -= c
        }
        if (stopFlag) throw StopRun()
    }

    // 連按 3 次音量下鍵 = 停止（任何畫面都有效）
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && running) {
            val now = System.currentTimeMillis()
            if (now - lastVol > 1500) volCount = 0
            lastVol = now
            volCount++
            if (volCount >= 3) {
                volCount = 0
                stopRun()
            }
        }
        return false
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun startRun(mode: String = "daily") {
        if (running) return
        running = true
        stopFlag = false
        Thread {
            try {
                doRun(mode)
            } catch (e: StopRun) {
                log("已手動停止")
                try {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                } catch (_: Exception) {
                }
            } catch (e: Throwable) {
                log("錯誤：$e")
            } finally {
                running = false
                releaseWake()
            }
        }.start()
    }

    private fun log(m: String) = Cfg.log(this, m)

    // ---------- 讀取畫面 ----------
    private fun txt(n: AccessibilityNodeInfo): String =
        (n.text?.toString()?.takeIf { it.isNotBlank() } ?: n.contentDescription?.toString() ?: "").trim()

    private fun flat(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) flat(n.getChild(i), out)
    }

    private fun appNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        val tp = targetPkg
        if (tp != null) {  // 優先讀 SolidMemory 自己的視窗
            try {
                for (w in windows) {
                    if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION && w.root?.packageName?.toString() == tp) {
                        flat(w.root, o)
                        if (o.isNotEmpty()) return o
                    }
                }
            } catch (_: Exception) {
            }
        }
        val r = rootInActiveWindow
        if (r != null) {
            flat(r, o)
            return o
        }
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    flat(w.root, o)
                    if (o.isNotEmpty()) break
                }
            }
        } catch (_: Exception) {
        }
        return o
    }

    private fun topPkg(): String? {
        val r = rootInActiveWindow
        if (r != null) return r.packageName?.toString()
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    val pk = w.root?.packageName?.toString()
                    if (pk != null) return pk
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun allNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) flat(w.root, o)
        } catch (_: Exception) {
        }
        if (o.isEmpty()) flat(rootInActiveWindow, o)
        return o
    }

    private fun imeNodes(): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) flat(w.root, o)
        } catch (_: Exception) {
        }
        return o
    }

    private fun editField(): AccessibilityNodeInfo? = appNodes().firstOrNull { it.isEditable }

    // 題目上的中文定義：只取「例句」之前的中文（後面是一長串例句翻譯，會把定義淹沒；
    // 實測整頁有 94～115 段中文，bounds 也無法過濾，所以用文件順序來切）
    private fun defChunks(ns: List<AccessibilityNodeInfo>): Set<String> {
        val o = LinkedHashSet<String>()
        for (n in ns) {
            val t = txt(n)
            if (t.startsWith("例句")) break
            for (m in cjkRe.findAll(t)) if (m.value !in uiChunks) o.add(m.value)
        }
        return o
    }

    // 只取畫面上方（鍵盤上面）看得到的中文，避免把隱藏頁面的文字也算進來
    private fun cjkTop(ns: List<AccessibilityNodeInfo>): Set<String> {
        val (_, h) = screenSize()
        return cjk(ns.filter {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.bottom > h * 0.1 && r.top < h * 0.62
        })
    }

    private fun cjk(ns: List<AccessibilityNodeInfo>): Set<String> {
        val o = HashSet<String>()
        for (n in ns) for (m in cjkRe.findAll(txt(n))) if (m.value !in uiChunks) o.add(m.value)
        return o
    }

    // ---------- 操作 ----------
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun gesture(g: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }
        dispatchGesture(g, cb, null)
        latch.await(3, TimeUnit.SECONDS)
        if (ok) gestureFails = 0 else gestureFails++
        return ok
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        return gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 90)).build())
    }

    private fun tapRatio(k: String) {
        val (rx, ry) = pos[k]!!
        val (w, h) = screenSize()
        tap(rx * w, ry * h)
    }

    private fun swipe(y1: Float, y2: Float, ms: Long) {
        val (w, h) = screenSize()
        val p = Path()
        p.moveTo(w / 2f, h * y1)
        p.lineTo(w / 2f, h * y2)
        gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build())
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {  // ACTION_CLICK（含往上找可點的父層）
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
        }
        return false
    }

    private fun tapNode(n: AccessibilityNodeInfo, stable: Boolean = false): Boolean {  // 在節點中心做真實觸控
        val r = Rect()
        n.getBoundsInScreen(r)
        if (stable) {  // 等位置不再移動（頁面轉場動畫中按鈕會移動）
            for (i in 1..4) {
                nap(350)
                n.refresh()
                val r2 = Rect()
                n.getBoundsInScreen(r2)
                if (r2 == r) break
                r.set(r2)
            }
        }
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        if (gestureOk() && tapNode(n)) return true
        return clickNode(n)
    }

    private fun waitNode(timeout: Long, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            val n = appNodes().firstOrNull(pred)
            if (n != null) return n
            nap(400)
        }
        return null
    }

    private fun clickText(t: String, fb: String, timeout: Long = 8000) {
        val n = waitNode(timeout) { txt(it) == t }
        if (n != null) click(n) else {
            log("找不到「$t」，改用座標點擊")
            tapRatio(fb)
        }
    }

    private fun promoShown(): Boolean = appNodes().any {
        val t = txt(it)
        t.contains("學生獎勵計劃") || t.contains("突破之旅") || t.contains("僅限學校用戶")
    }

    // 新加坡旅行彈窗：點旁邊灰色區域，不行再按返回
    private fun closePromo() {
        if (!promoShown()) return
        val (w, h) = screenSize()
        log("關閉彈窗")
        for (i in 1..4) {
            when (i) {
                1 -> tap(w / 2f, h * 0.25f)
                2 -> tap(w / 2f, h * 0.064f)
                3 -> tap(w / 2f, h * 0.80f)
                else -> performGlobalAction(GLOBAL_ACTION_BACK)
            }
            nap(900)
            if (!promoShown()) return
        }
    }

    // 點按鈕並確認真的進到下一頁（出現 expect 文字）；依序換方法重試
    private fun clickUntil(label: String, expect: String, fb: String, scroll: Boolean = false): Boolean {
        for (m in 0..3) {
            var n = waitNode(if (m == 0) 15000L else 3000L) { txt(it) == label }
            if (n == null && scroll) {
                for (i in 0..8) {
                    swipe(0.80f, 0.35f, 400)
                    nap(700)
                    n = appNodes().firstOrNull { txt(it) == label }
                    if (n != null) break
                }
            }
            when (m) {
                0 -> if (n != null) { if (gestureOk()) tapNode(n, true) else clickNode(n) }
                1 -> if (n != null) clickNode(n)
                2 -> tapRatio(fb)
                else -> {
                    closePromo()
                    if (n != null) tapNode(n, true)
                }
            }
            nap(1500)
            if (waitNode(3000L) { txt(it).contains(expect) } != null) {
                log("「$label」成功（第 ${m + 1} 種方法）")
                return true
            }
            closePromo()
        }
        log("點「$label」後沒有進到下一頁")
        return false
    }

    // 往下滑直到看到按鈕（輸入頁要滑到最底才看得到「做練習」）
    private fun clickTextScroll(t: String, fb: String) {
        for (i in 0..8) {
            val n = appNodes().firstOrNull { txt(it) == t }
            if (n != null) {
                click(n)
                return
            }
            swipe(0.80f, 0.35f, 400)
            nap(700)
        }
        log("滑不到「$t」，改用座標點擊")
        tapRatio(fb)
    }

    private fun tapNext() {
        val n = appNodes().firstOrNull { txt(it).contains("下一個") }
        if (n != null) click(n) else tapRatio("next")
    }

    private fun setText(n: AccessibilityNodeInfo, s: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    // ---------- 解鎖 ----------
    // PIN 鍵的文字是 "5" 或 "5 JKL"；鎖屏時鐘的 "3\n30" 不符合這個格式
    private val padRe = Regex("^(\\d)(?:\\s*[A-Za-z+]*)?$")

    private fun padKeys(): List<Pair<Char, AccessibilityNodeInfo>> {
        val out = ArrayList<Pair<Char, AccessibilityNodeInfo>>()
        for (n in allNodes()) {
            for (t in listOf(n.text?.toString(), n.contentDescription?.toString())) {
                if (t == null) continue
                val m = padRe.matchEntire(t.trim()) ?: continue
                out.add(Pair(m.groupValues[1][0], n))
                break
            }
        }
        return out
    }

    // 同一個數字有好幾個節點時（例如時鐘的「3」），取最靠下面的那個＝鍵盤上的鍵
    private fun keyNode(d: Char): AccessibilityNodeInfo? =
        padKeys().filter { it.first == d }.maxByOrNull {
            val r = Rect()
            it.second.getBoundsInScreen(r)
            r.centerY()
        }?.second

    private fun padShown(): Boolean = padKeys().map { it.first }.toSet().size >= 8

    private fun waitPad(ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (padShown()) return true
            nap(300)
        }
        return false
    }

    private fun unlock(km: KeyguardManager): Boolean {
        if (!km.isKeyguardLocked) return true
        val pin = Cfg.str(this, "pin")
        if (pin.isBlank()) {
            log("手機鎖著，但沒設定 PIN")
            return false
        }
        var entered = 0
        for (i in 1..6) {
            if (!km.isKeyguardLocked) return true
            if (!waitPad(300)) {  // PIN 鍵盤還沒出現 → 叫出來
                when (i % 3) {
                    1 -> swipe(0.90f, 0.30f, 450)
                    2 -> startActivity(Intent(this, UnlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    else -> swipe(0.95f, 0.20f, 600)
                }
                val shown = waitPad(3500)
                log("第 $i 次叫出 PIN 鍵盤：" + (if (shown) "成功" else "沒出現"))
                if (!shown) continue
            }
            if (entered >= 2) break  // 最多輸入 2 次，避免輸錯被鎖機
            entered++
            var ok = true
            for (d in pin) {
                val n = keyNode(d)
                if (n == null || !click(n)) {
                    ok = false
                    break
                }
                nap(250)
            }
            if (!ok) {
                log("PIN 輸入中斷")
                continue
            }
            nap(500)
            val enter = allNodes().firstOrNull { txt(it) in listOf("確認", "確定", "OK", "Enter", "Done", "輸入") }
            if (enter != null) click(enter)
            nap(2000)
            if (!km.isKeyguardLocked) {
                log("已解鎖")
                return true
            }
        }
        return false
    }

    // 診斷：看看服務到底讀得到什麼、手勢能不能用
    private fun diag() {
        log("診斷：8 秒後讀取目前畫面，請現在切到 SolidMemory")
        nap(8000)
        val ns = appNodes()
        log("最上層 App ${topPkg()}，節點 ${ns.size}，全部視窗節點 ${allNodes().size}")
        val wins = try {
            windows.joinToString(",") { "${it.type}:${it.root?.packageName ?: "?"}" }
        } catch (e: Exception) {
            "讀取失敗"
        }
        log("視窗（類型:套件）$wins")
        val tops = ns.filter { txt(it).isNotEmpty() }.take(30)
        log("文字：" + tops.joinToString(" | ") { txt(it).take(12) + (if (it.isClickable) "*" else "") })
        gestureFails = 0
        swipe(0.6f, 0.5f, 300)
        log("手勢測試：" + (if (gestureFails == 0) "成功" else "失敗"))
    }

    private fun appOpen(pkg: String): Boolean {
        if (topPkg() == pkg) return true
        return allNodes().any {
            val t = txt(it)
            t == "詞彙學習" || t.contains("透過閱讀學習")
        }
    }

    @Suppress("DEPRECATION")
    private fun launchApp(): String? {
        val key = Cfg.str(this, "app").ifBlank { "SolidMemory" }
        val pm = packageManager
        val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(key, true) }
        if (ri == null) {
            log("找不到名稱含「$key」的 App")
            return null
        }
        val pkg = ri.activityInfo.packageName
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(pkg, ri.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        targetPkg = null
        startActivity(intent)
        val t0 = System.currentTimeMillis()
        var resent = false
        while (System.currentTimeMillis() - t0 < 35000) {
            if (appOpen(pkg)) {
                targetPkg = pkg
                nap(2500)
                return pkg
            }
            if (!resent && System.currentTimeMillis() - t0 > 12000) {
                resent = true
                log("App 還沒出現，再送一次啟動")
                startActivity(intent)
            }
            nap(500)
        }
        log("App 沒有開起來（請確認已允許「顯示在其他應用程式上層」）")
        return null
    }

    // ---------- 輸入新詞 ----------
    private fun fieldText(f: AccessibilityNodeInfo): String {
        f.refresh()
        return f.text?.toString()?.trim() ?: ""
    }

    private fun addEnabled(): Boolean = appNodes().firstOrNull { txt(it) == "加入" }?.isEnabled == true

    // 搜尋建議清單：依需求文件不收起，單純按放大鏡（保留這個空函式，呼叫處不用改）
    private fun closeDropdown() {}

    private fun tapAt(rx: Float, ry: Float) {
        val (w, h) = screenSize()
        tap(rx * w, ry * h)
    }

    private fun imeVisible(): Boolean = imeNodes().isNotEmpty()

    // 螢幕鍵盤只在「讀得到字母鍵」時才用（不再用座標，因為你的鍵盤會切成手寫）
    private fun typeViaKeyboard(s: String): Boolean {
        if (!imeVisible()) return false
        val keys = imeNodes()
        for (c in s) {
            val node: AccessibilityNodeInfo? = if (c == ' ') {
                keys.firstOrNull { txt(it) in listOf("Space", "空白鍵", "空格") }
            } else {
                keys.firstOrNull { txt(it).equals(c.toString(), true) }
            }
            if (node == null || !tapNode(node)) return false
            nap(130)
        }
        return true
    }

    private fun pasteInto(f: AccessibilityNodeInfo, text: String): Boolean {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("w", text))
        setText(f, "")
        nap(300)
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        f.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        nap(700)
        val g = editField() ?: return false
        return fieldText(g).equals(text, true)
    }

    // 按放大鏡後耐心等定義出現（最多 12 秒），不連續亂按；真的沒出現才再按一次
    private fun searchAndRead(bt: Set<String>): Pair<List<AccessibilityNodeInfo>, Set<String>> {
        for (attempt in 1..2) {
            tapRatio("search")
            val end = System.currentTimeMillis() + 12000
            while (System.currentTimeMillis() < end) {
                nap(700)
                val ns = appNodes()
                if (cjk(ns.filter { txt(it) !in bt }).isNotEmpty()) {
                    nap(1000)  // 等整頁載完
                    val ns2 = appNodes()
                    return Pair(ns2, cjk(ns2.filter { txt(it) !in bt }))
                }
            }
            if (attempt == 1) {
                log("等了 12 秒沒出現定義，收起清單後再按一次")
                closeDropdown()
            }
        }
        val ns = appNodes()
        return Pair(ns, cjk(ns.filter { txt(it) !in bt }))
    }

    // 輸入單字：貼上 → 直接寫入 → 鍵盤。成功與否只看輸入框的文字對不對
    // （「加入」要搜尋之後才會變可按，之前拿它當標準是誤判）
    private fun typeWord(w: String): Boolean {
        val f = editField() ?: return false
        if (pasteInto(f, w)) return true
        log("貼上沒成功，改用直接寫入")
        val f2 = editField() ?: return false
        setText(f2, w)
        nap(700)
        if (fieldText(editField() ?: f2).equals(w, true)) return true
        log("直接寫入也沒成功，改用螢幕鍵盤")
        setText(editField() ?: f2, "")
        nap(300)
        if (typeViaKeyboard(w)) {
            nap(600)
            val g = editField()
            return g != null && fieldText(g).equals(w, true)
        }
        return false
    }

    private fun counter(ns: List<AccessibilityNodeInfo>): Int? {
        for (n in ns) {
            val m = counterRe.find(txt(n))
            if (m != null) return m.groupValues[1].toInt() + m.groupValues[2].toInt()
        }
        return null
    }

    private fun enterWords(pool: MutableList<String>, n: Int): Pair<List<String>, List<String>> {
        val added = ArrayList<String>()
        val dupes = ArrayList<String>()
        var dupRun = 0
        var typeFails = 0
        while (added.size < n && pool.isNotEmpty() && dupRun < 6) {
            val w = pool.removeAt(0)
            val before = appNodes()
            val b0 = counter(before)
            val bt = before.map { txt(it) }.toSet()
            clickText("清除", "clear", 3000)
            nap(300)
            if (!typeWord(w)) {
                typeFails++
                log("輸入「$w」失敗（網頁沒接受文字）")
                if (typeFails >= 3) {
                    log("連續 3 次輸入失敗，停止")
                    break
                }
                continue
            }
            typeFails = 0
            closeDropdown()
            val sr = searchAndRead(bt)  // 放大鏡：顯示定義（會等到出現）
            val searched = sr.first
            val chunks = sr.second
            val st = searched.map { txt(it) }.toSet()
            closeDropdown()
            clickText("加入", "add", 3000)
            nap(1200)
            val after = appNodes()
            val a0 = counter(after)
            val msg = after.map { txt(it) }.toSet() - st
            val dupMsg = msg.any { t -> dupWords.any { t.contains(it, true) } }
            val ok = if (b0 != null && a0 != null) (a0 > b0 && !dupMsg) else !dupMsg
            Cfg.addUsed(this, w)
            if (ok) {
                added.add(w)
                dupRun = 0
                if (chunks.isNotEmpty()) Db.append(this, "temp.tsv", w, chunks) else log("⚠ $w 沒讀到定義")
                log("加入 $w (${added.size}/$n)")
            } else {
                dupes.add(w)
                dupRun++
                log("$w 重複，換下一個")
            }
        }
        if (dupRun >= 6) log("連續 6 個都判定重複，可能判斷有誤，已停止")
        return Pair(added, dupes)
    }

    // ---------- 練習 ----------
    // 題目頂端的格式，例如「____d _______」（片語會有空格）
    private fun findPattern(ns: List<AccessibilityNodeInfo>): String? {
        val (_, h) = screenSize()
        val parts = ArrayList<Pair<Int, String>>()
        for (n in ns) {
            val t = txt(n).trim()
            if (t.length < 2 || t.none { it in blank }) continue
            if (!t.all { it in blank || it == ' ' || it in 'a'..'z' || it in 'A'..'Z' }) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.centerY() > h * 0.2) continue
            parts.add(Pair(r.centerX(), t))
        }
        if (parts.isEmpty()) return null
        return parts.sortedBy { it.first }.joinToString(" ") { it.second }.replace(Regex("\\s+"), " ")
    }

    // 用題目上的中文定義／例句翻譯，去詞庫找對應單字
    private fun match(chunks: Set<String>, pat: String, db: Map<String, Set<String>>): String? {
        lastBestWord = null
        lastInfo = "沒有中文定義"
        if (chunks.isEmpty()) return null
        val groups = pat.lowercase().split(" ").filter { it.isNotEmpty() }
        var best: String? = null
        var bestScore = 0.0
        var second = 0.0
        for ((w, ch) in db) {
            val toks = w.split(" ")
            if (toks.size != groups.size) continue
            var ok = true
            for (i in toks.indices) {
                if (Math.abs(toks[i].length - groups[i].length) > 1) {
                    ok = false
                    break
                }
            }
            if (!ok) continue
            var hintOk = true
            for (i in toks.indices) {
                if (toks[i].length != groups[i].length) continue
                for (j in toks[i].indices) {
                    val g = groups[i][j]
                    if (g.isLetter() && g != toks[i][j]) hintOk = false
                }
            }
            if (!hintOk) continue
            val s = chunks.count { it in ch }.toDouble() / chunks.size
            if (s > bestScore) {
                second = bestScore
                bestScore = s
                best = w
            } else if (s > second) {
                second = s
            }
        }
        lastBestWord = best
        lastInfo = "最佳 $best 分數 ${"%.2f".format(bestScore)}，第二 ${"%.2f".format(second)}"
        return if (best != null && bestScore >= 0.75 && bestScore - second >= 0.15 && second < bestScore) best else null
    }

    private fun patNode(): AccessibilityNodeInfo? {
        val (_, h) = screenSize()
        return appNodes().firstOrNull {
            val t = txt(it).trim()
            if (t.length < 2 || t.none { c -> c in blank }) return@firstOrNull false
            val r = Rect()
            it.getBoundsInScreen(r)
            r.centerY() < h * 0.2
        }
    }

    private fun typeAnswer(ans: String) {
        var f = editField()
        if (f == null) {  // 找不到輸入框：點一下題目那一行，讓輸入框出現
            patNode()?.let { tapNode(it) }
            nap(800)
            f = editField()
        }
        if (!typeLogged) {
            typeLogged = true
            log("作答輸入框：" + (if (f != null) "找到" else "找不到"))
        }
        if (f != null) {
            if (pasteInto(f, ans)) return
            setText(f, ans)
            if (fieldText(editField() ?: f).equals(ans, true)) return
        }
        typeViaKeyboard(ans)
    }

    // 送出：按鍵盤右下角的「前往」，不行再試 IME Enter，最後按「下一個」
    private fun submit() {
        val e = imeNodes().firstOrNull { txt(it) in listOf("前往", "Go", "Enter", "完成", "搜尋", "下一步") }
        if (e != null && tapNode(e)) return
        val f = editField()
        if (f != null && Build.VERSION.SDK_INT >= 30 &&
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        ) return
        tapNext()
    }

    private fun fitsPat(pat: String, w: String): Boolean {
        val groups = pat.lowercase().split(" ").filter { it.isNotEmpty() }
        val toks = w.split(" ")
        if (toks.size != groups.size) return false
        for (i in toks.indices) {
            if (Math.abs(toks[i].length - groups[i].length) > 1) return false
            if (toks[i].length == groups[i].length) {
                for (j in toks[i].indices) {
                    val g = groups[i][j]
                    if (g.isLetter() && g != toks[i][j]) return false
                }
            }
        }
        return true
    }

    // 答錯後畫面上方會用紅字顯示正確單字：逐個節點、以及合併後都試，且優先挑「不是我剛打的字」
    private fun revealedWord(ns: List<AccessibilityNodeInfo>, pat: String, typed: String?): String? {
        val (_, h) = screenSize()
        val texts = ArrayList<Pair<Int, String>>()
        for (n in ns) {
            val t = txt(n).trim()
            if (t.isEmpty() || !plainRe.matches(t)) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.centerY() > h * 0.2) continue
            texts.add(Pair(r.centerX(), t.lowercase().replace(Regex("\\s+"), " ")))
        }
        if (texts.isEmpty()) return null
        val ordered = texts.sortedBy { it.first }.map { it.second }
        val cands = ordered + listOf(ordered.joinToString(" "))
        val other = cands.firstOrNull { fitsPat(pat, it) && it != typed }
        if (other != null) return other
        return cands.firstOrNull { fitsPat(pat, it) }
    }

    // ---------- Gemini App：收鍵盤 → 截圖 → 分享給 Gemini → 讀它的回答 → 回到 SolidMemory ----------
    private val gemPkgs = setOf("com.google.android.apps.bard", "com.google.android.googlequicksearchbox")
    private val ansRe = Regex("【答案】[ \\t*：:\"“”「」]*([A-Za-z][A-Za-z '’\\-]*)")
    private val sendRe = Regex(
        "^(傳送|发送|發送|送出|提交|send|submit)(\\s*(訊息|消息|提示|message|prompt))?$",
        RegexOption.IGNORE_CASE
    )

    @Volatile
    private var lostApp = false
    private var gemFails = 0

    private fun rectOf(n: AccessibilityNodeInfo): Rect {
        val r = Rect()
        n.getBoundsInScreen(r)
        return r
    }

    private fun imeUp(): Boolean {
        try {
            if (windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }) return true
        } catch (_: Exception) {
        }
        return imeNodes().isNotEmpty()
    }

    // 截圖前一定要先收起鍵盤。做法＝按螢幕最下面三顆鍵最右邊那顆（鍵盤出現時它會變成 v），也就是「返回」鍵。
    // 只在鍵盤真的在畫面上時才按，否則會退出練習頁。
    private fun hideKeyboard(): Boolean {
        for (i in 1..2) {
            if (!imeUp()) return true
            performGlobalAction(GLOBAL_ACTION_BACK)
            nap(900)
        }
        return !imeUp()
    }

    // 截圖：只存在本 App 的暫存資料夾（下一題會刪掉），成功回傳檔名
    private fun takeShot(): String? {
        if (Build.VERSION.SDK_INT < 30) {
            log("系統版本太舊，無法截圖（需要 Android 11 以上）")
            return null
        }
        for (attempt in 1..2) {
            val latch = CountDownLatch(1)
            var bmp: Bitmap? = null
            var err = 0
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                        hb.close()
                    } catch (e: Throwable) {
                        err = -2
                    }
                    latch.countDown()
                }

                override fun onFailure(errorCode: Int) {
                    err = errorCode
                    latch.countDown()
                }
            })
            latch.await(6, TimeUnit.SECONDS)
            val b = bmp
            if (b != null) {
                val dir = File(cacheDir, "shots")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val name = "q" + System.currentTimeMillis() + ".jpg"
                FileOutputStream(File(dir, name)).use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                log("截圖成功（${b.width}x${b.height}）")
                return name
            }
            log("截圖失敗（代碼 ${err}；3＝太快、2＝沒有截圖權限，請把無障礙服務關掉再開）")
            if (err == 3) nap(1500) else break
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun geminiPkg(): String? {
        val key = Cfg.str(this, "gemApp").ifBlank { "Gemini" }
        val pm = packageManager
        val hit = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(key, true) }
        if (hit != null) return hit.activityInfo.packageName
        return try {
            pm.getPackageInfo("com.google.android.apps.bard", 0)
            "com.google.android.apps.bard"
        } catch (e: Exception) {
            null
        }
    }

    // Gemini 的視窗（也包含 Google App 的浮動視窗）
    private fun geminiNodes(gpkg: String?): List<AccessibilityNodeInfo> {
        val o = ArrayList<AccessibilityNodeInfo>()
        val pk = HashSet<String>(gemPkgs)
        if (gpkg != null) pk.add(gpkg)
        try {
            for (w in windows) {
                val r = w.root ?: continue
                val p = r.packageName?.toString()
                if (p != null && p in pk) flat(r, o)
            }
        } catch (_: Exception) {
        }
        return o
    }

    private fun waitG(gpkg: String?, timeout: Long, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            val n = geminiNodes(gpkg).firstOrNull(pred)
            if (n != null) return n
            nap(500)
        }
        return null
    }

    private fun waitAll(timeout: Long, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            val n = allNodes().firstOrNull(pred)
            if (n != null) return n
            nap(500)
        }
        return null
    }

    // 把 Gemini 畫面上的文字寫進記錄（* = 可點，✎ = 輸入框），方便出問題時貼回來
    private fun dumpG(gpkg: String?) {
        val ns = geminiNodes(gpkg)
        val items = ns.filter { txt(it).isNotEmpty() }.map {
            txt(it).take(14) + (if (it.isClickable) "*" else "") + (if (it.isEditable) "✎" else "")
        }
        val shown = if (items.size > 40) items.take(12) + listOf("…") + items.takeLast(28) else items
        log("Gemini 畫面（${ns.size} 個節點）：" + shown.joinToString(" | ").take(700))
    }

    private fun geminiPrompt(pat: String, chunks: Set<String>, withImage: Boolean): String {
        val lens = pat.split(" ").filter { it.isNotEmpty() }.joinToString("+") { it.length.toString() }
        val head = if (withImage) {
            "這是英文單字填空題的截圖（鍵盤已收起）。"
        } else {
            "這是英文單字填空題（沒有截圖，只有文字）。中文定義：" + chunks.take(15).joinToString("、") + "。"
        }
        return head + "題目格式：${pat}（每個底線是一個字母，已顯示的字母位置固定；空格代表片語的單字分隔；字母數 ${lens}）。" +
            "請根據中文定義、英文解釋和例句，找出被挖空的英文單字，字母數與已顯示的字母必須完全吻合。" +
            "不要解釋，只回答一行，格式：【答案】單字"
    }

    private fun makeShare(prompt: String, shot: String?): Intent {
        val i = Intent(Intent.ACTION_SEND)
        if (shot != null) {
            val uri = Uri.parse("content://" + ShotProvider.AUTH + "/" + shot)
            i.type = "image/jpeg"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.clipData = ClipData.newRawUri("shot", uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            i.type = "text/plain"
        }
        i.putExtra(Intent.EXTRA_TEXT, prompt)
        return i
    }

    // 分享給 Gemini：先直接指定 Gemini；不行再開分享選單點「Gemini」
    private fun shareToGemini(gpkg: String?, prompt: String, shot: String?): Boolean {
        if (gpkg != null) {
            val i = makeShare(prompt, shot)
            i.setPackage(gpkg)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)  // 每題都是新的對話
            try {
                startActivity(i)
                return true
            } catch (e: Exception) {
                log("直接分享給 Gemini 失敗（${e}），改用分享選單")
            }
        }
        try {
            startActivity(Intent.createChooser(makeShare(prompt, shot), "Gemini").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            log("開不了分享選單：${e}")
            return false
        }
        val key = Cfg.str(this, "gemApp").ifBlank { "Gemini" }
        val n = waitAll(10000) { txt(it).contains(key, true) }
        if (n == null) {
            log("分享選單裡找不到「${key}」")
            return false
        }
        click(n)
        return true
    }

    // 已經送出 = 輸入框裡不再有我們的提示詞
    private fun gemSent(gpkg: String?): Boolean =
        geminiNodes(gpkg).none { it.isEditable && fieldText(it).contains("【答案】") }

    // 在 Gemini 裡確認提示詞已帶入、再按傳送
    private fun geminiSend(gpkg: String?, prompt: String): Boolean {
        val (w, _) = screenSize()
        val field = waitG(gpkg, 20000) { it.isEditable }
        if (field == null) {
            log("Gemini 裡找不到輸入框")
            return false
        }
        if (geminiNodes(gpkg).any { !it.isEditable && txt(it).contains("【答案】") }) {
            log("Gemini 已經自動送出了")
            return true
        }
        if (!fieldText(field).contains("【答案】")) {
            log("Gemini 輸入框沒有自動帶入提示詞，自己貼上")
            setText(field, prompt)
            nap(800)
            if (!fieldText(field).contains("【答案】")) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("p", prompt))
                field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                field.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                nap(800)
            }
        }
        nap(1200)  // 等圖片附件讀進來、傳送鈕出現
        for (round in 1..8) {
            val ns = geminiNodes(gpkg)
            val sn = ns.firstOrNull { it.isEnabled && sendRe.matches(txt(it).trim()) }
            if (sn != null) {
                log("按「${txt(sn)}」")
                if (round % 2 == 1) click(sn) else clickNode(sn)
                nap(1500)
                if (gemSent(gpkg)) return true
            }
            nap(700)
        }
        // 備用：點輸入框那一排最右邊的小按鈕
        val ns = geminiNodes(gpkg)
        val f = ns.firstOrNull { it.isEditable }
        if (f != null) {
            val fr = rectOf(f)
            val cand = ns.filter {
                val r = rectOf(it)
                it.isClickable && !it.isEditable && r.width() < 260 && r.height() < 260 &&
                    r.centerX() > w * 0.75 && r.centerY() > fr.top - 60 && r.centerY() < fr.bottom + 320
            }
            val pick = cand.maxByOrNull { rectOf(it).centerX() * 10000L + rectOf(it).centerY() }
            if (pick != null) {
                log("找不到傳送鈕，改點最右邊的按鈕：${txt(pick).take(10)}")
                click(pick)
                nap(1500)
                if (gemSent(gpkg)) return true
            }
        }
        return false
    }

    private fun geminiAnswers(ns: List<AccessibilityNodeInfo>): List<String> {
        val o = ArrayList<String>()
        for (n in ns) {
            for (m in ansRe.findAll(txt(n))) o.add(m.groupValues[1])
        }
        return o
    }

    private fun fitsExact(pat: String, w: String): Boolean {
        val groups = pat.lowercase().split(" ").filter { it.isNotEmpty() }
        val toks = w.lowercase().split(" ").filter { it.isNotEmpty() }
        if (toks.size != groups.size) return false
        for (i in toks.indices) {
            if (toks[i].length != groups[i].length) return false
            for (j in toks[i].indices) {
                val g = groups[i][j]
                if (g.isLetter() && g != toks[i][j]) return false
            }
        }
        return true
    }

    // 從 Gemini 回的那一行取出答案：取前 k 個字（k＝題目有幾個單字），再檢查格式
    private fun pickAnswer(raw: String, pat: String, strict: Boolean): String? {
        val k = pat.split(" ").count { it.isNotEmpty() }
        val toks = raw.lowercase().replace(Regex("\\s+"), " ").trim().split(" ").filter { it.isNotEmpty() }
        if (k == 0 || toks.size < k) return null
        val cand = toks.take(k).joinToString(" ")
        val ok = if (strict) fitsExact(pat, cand) else fitsPat(pat, cand)
        return if (ok) cand else null
    }

    // 等 Gemini 回答完：串流中字會一個一個出現，所以要「格式吻合、而且連續兩次讀到一樣」才算
    private fun geminiWaitAnswer(gpkg: String?, pat: String, base: Int): String? {
        val end = System.currentTimeMillis() + 150000
        var lastRaw = ""
        var stable = 0
        while (System.currentTimeMillis() < end) {
            nap(1500)
            val a = geminiAnswers(geminiNodes(gpkg))
            if (a.size <= base) continue
            val raw = a.last().trim()
            if (raw == lastRaw) stable++ else {
                stable = 0
                lastRaw = raw
            }
            val strictAns = pickAnswer(raw, pat, true)
            if (strictAns != null && stable >= 1) {
                log("Gemini 回答：${strictAns}")
                return strictAns
            }
            val looseAns = pickAnswer(raw, pat, false)
            if (looseAns != null && stable >= 3) {
                log("Gemini 回答：${looseAns}（字母數差 1 以內）")
                return looseAns
            }
            if (stable >= 5) {
                log("Gemini 的回答「${raw}」不符合題目格式 ${pat}")
                return null
            }
        }
        log("等了 150 秒沒讀到 Gemini 的答案")
        dumpG(gpkg)
        return null
    }

    private fun targetVisible(): Boolean {
        val tp = targetPkg ?: return false
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION && w.root?.packageName?.toString() == tp) return true
            }
        } catch (_: Exception) {
        }
        return false
    }

    @Suppress("DEPRECATION")
    private fun resumeApp(pkg: String) {
        val pm = packageManager
        val ri = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg), 0
        ).firstOrNull() ?: return
        // 和 launchApp 同一個啟動圖示，但不清除任務 → 回到原本的畫面
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(pkg, ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // 從 Gemini 回到 SolidMemory：按返回（每次按之前先確認還沒回到），不行再用啟動圖示
    private fun backToApp(gpkg: String?): Boolean {
        for (i in 1..5) {
            val vis = targetVisible()
            val gem = geminiNodes(gpkg).isNotEmpty()
            if (vis && (!gem || i > 2)) {
                nap(800)
                log("已回到 SolidMemory")
                return true
            }
            performGlobalAction(GLOBAL_ACTION_BACK)
            nap(1200)
        }
        if (targetVisible()) {
            log("已回到 SolidMemory")
            return true
        }
        val pkg = targetPkg
        if (pkg != null) {
            log("按返回回不去，改用啟動圖示")
            resumeApp(pkg)
            for (i in 1..16) {
                nap(500)
                if (targetVisible()) {
                    nap(800)
                    log("已回到 SolidMemory")
                    return true
                }
            }
        }
        log("回不到 SolidMemory")
        return false
    }

    // 問 Gemini 一題。回傳答案（已確認符合題目格式），沒有答案回傳 null；回不到 SolidMemory 時 lostApp = true
    private fun askGemini(pat: String, chunks: Set<String>): String? {
        lostApp = false
        val gpkg = geminiPkg()
        if (gpkg == null) {
            log("找不到 Gemini App（請確認有安裝，或在設定欄填它的名稱）")
            return null
        }
        val hid = hideKeyboard()
        log("收起鍵盤：" + (if (hid) "成功（或本來就沒有鍵盤）" else "失敗，鍵盤可能還在"))
        nap(800)
        val shot = takeShot()
        val prompt = geminiPrompt(pat, chunks, shot != null)
        log("傳給 Gemini：" + (if (shot != null) "截圖＋文字" else "只有文字") + "，題目 ${pat}")
        if (!shareToGemini(gpkg, prompt, shot)) {
            log("分享給 Gemini 失敗")
            if (!backToApp(gpkg)) lostApp = true
            return null
        }
        nap(1500)
        if (waitG(gpkg, 25000) { true } == null) {
            log("Gemini 沒有開起來")
            if (!backToApp(gpkg)) lostApp = true
            return null
        }
        val base = geminiAnswers(geminiNodes(gpkg)).size
        if (!geminiSend(gpkg, prompt)) {
            log("沒辦法在 Gemini 按傳送")
            dumpG(gpkg)
            if (!backToApp(gpkg)) lostApp = true
            return null
        }
        val ans = geminiWaitAnswer(gpkg, pat, base)
        if (!backToApp(gpkg)) lostApp = true
        return ans
    }

    private fun practice(db: Map<String, Set<String>>) {
        val all = HashMap<String, Set<String>>(db)  // 新詞暫存 + 舊詞庫 + 本次答錯學到的字
        var learned = 0
        var misses = 0
        var lastKey = ""
        var same = 0
        var gemOn = Cfg.p(this).getBoolean("gemOn", true)
        gemFails = 0
        for (i in 1..200) {
            val items = appNodes()
            val pat = findPattern(items)
            if (pat == null) {
                misses++
                if (misses >= 3) {
                    log("練習結束（本次答錯學到 $learned 個，已丟棄）")
                    return
                }
                tapNext()
                nap(1000)
                continue
            }
            misses = 0
            val chunks = defChunks(items)
            val key = pat + chunks.sorted().joinToString("")
            if (key == lastKey) same++ else {
                same = 0
                lastKey = key
            }
            if (same >= 3) {
                log("卡在同一題（$pat），已停止，請看畫面")
                return
            }
            // 順序：暫存詞庫（有把握才用）→ 截圖問 Gemini → 都沒有就猜一個最接近的
            val m = match(chunks, pat, all)
            var typed: String? = if (same >= 2) null else m
            var src = "詞庫"
            if (typed == null && gemOn) {
                val g = askGemini(pat, chunks)
                if (lostApp) {
                    log("回不到 SolidMemory，已停止")
                    return
                }
                if (g != null) {
                    typed = g
                    src = "Gemini"
                    gemFails = 0
                } else {
                    gemFails++
                    if (gemFails >= 3) {
                        gemOn = false
                        log("Gemini 連續 3 次沒給出答案，這次剩下的題目改用猜的")
                    }
                }
                nap(800)
            }
            if (typed == null) {
                // 沒把握也照樣答：跳過本來就算答錯，答錯時畫面才會用紅字顯示正確答案
                typed = lastBestWord ?: "a"
                src = "猜"
                log("Q$i $pat 沒把握（定義 ${chunks.size} 段；$lastInfo），先答 $typed")
            }
            val ans: String = typed ?: "a"
            typeAnswer(ans)
            nap(400)
            submit()
            var rv: String? = null
            var advanced = false
            for (k in 1..6) {  // 紅字可能晚一點才出現
                nap(600)
                val a = appNodes()
                rv = revealedWord(a, pat, ans)
                if (rv != null && rv != ans) break
                val p2 = findPattern(a)
                if (p2 != null && p2 != pat) {
                    advanced = true
                    break
                }
            }
            if (advanced) {
                log("Q$i $pat → $ans（$src）")
                continue
            }
            if (rv != null && rv != ans) {
                if (rv !in all) learned++
                all[rv] = chunks  // 用這題的中文定義配上正確單字，之後「錯誤單字溫習」就認得
                log("Q$i $pat 答錯（$src 答 $ans），正確是 $rv，已暫存")
                typeAnswer(rv)  // 把紅字的正確答案打一遍
                nap(400)
                submit()
                nap(1000)
                val p3 = findPattern(appNodes())
                if (p3 == null || p3 == pat) {
                    tapNext()
                    nap(1000)
                }
                continue
            }
            log("Q$i $pat → $ans（$src，沒讀到紅字）")
            val p4 = findPattern(appNodes())
            if (p4 == null || p4 == pat) {
                tapNext()
                nap(1000)
            }
        }
    }

    // ---------- 主流程 ----------
    private fun removeFromFuture(done: Set<String>) {
        val keep = Cfg.str(this, "words").lines().filter { it.trim().lowercase() !in done }
        Cfg.p(this).edit().putString("words", keep.joinToString("\n")).apply()
    }

    private fun dailyRun() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (Cfg.str(this, "lastEnter") == today) {
            log("今天已輸入過新詞，這次只做練習")
        } else {
            val old = Db.load(this, "db.tsv")
            val used = Cfg.usedSet(this)
            val pool = Cfg.wordList(this, "words").filter { it !in used && it !in old }.distinct().toMutableList()
            if (pool.isEmpty()) {
                log("沒有可用的候選單字，這次只做練習")
            } else {
                if (!clickUntil("輸入詞彙", "加入", "input")) return
                nap(1200)
                val r = enterWords(pool, 5)
                val done = (r.first + r.second).toSet()
                if (done.isNotEmpty()) removeFromFuture(done)  // 這幾個從「未來學習」清單刪除
                if (r.first.isNotEmpty()) Cfg.p(this).edit().putString("lastEnter", today).apply()
                if (imeNodes().isNotEmpty()) {
                    performGlobalAction(GLOBAL_ACTION_BACK)  // 收起鍵盤
                    nap(600)
                }
            }
        }
        val db = Db.load(this, "db.tsv")
        db.putAll(Db.load(this, "temp.tsv"))  // 新詞暫存，練習用
        if (!clickUntil("做練習", "下一個", "practice", true)) return  // 輸入頁要滑到最底才看到
        nap(1800)
        practice(db)
        Db.merge(this)  // 新詞練習完 → 併入舊詞庫，暫存清空
    }

    private fun report(step: String, ok: Boolean, extra: String = "") =
        log((if (ok) "✔ " else "✘ ") + step + (if (extra.isNotEmpty()) "：$extra" else ""))

    // 逐步測試：每個動作都回報成功或失敗，不會按「加入」，不改任何資料
    private fun selfTest() {
        report("開啟 App、關彈窗、進入「詞彙學習」", true)
        val inp = clickUntil("輸入詞彙", "加入", "input")
        report("按「輸入詞彙」", inp)
        if (!inp) return
        nap(1000)
        clickText("清除", "clear", 3000)
        nap(300)
        report("輸入單字，網頁有接受", typeWord("test"))
        closeDropdown()
        val bt = appNodes().map { txt(it) }.toSet()
        val ch = searchAndRead(bt).second
        report("按放大鏡，讀到定義", ch.isNotEmpty(), "新出現中文 ${ch.size} 段")
        closeDropdown()
        clickText("清除", "clear", 3000)
        nap(500)
        val f = editField()
        report("按「清除」", f != null && fieldText(f).isEmpty())
        if (imeNodes().isNotEmpty()) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            nap(600)
        }
        val pr = clickUntil("做練習", "下一個", "practice", true)
        report("滑到底按「做練習」進入練習畫面", pr)
        if (pr) {
            nap(1500)
            val items = appNodes()
            val pat = findPattern(items)
            report("讀到題目格式", pat != null, pat ?: "")
            report("讀到題目的中文定義", defChunks(items).isNotEmpty(), "定義 ${defChunks(items).size} 段（整頁 ${cjk(items).size} 段）")
            if (pat != null) {
                val g = askGemini(pat, defChunks(items))
                report("Gemini 判斷（收鍵盤→截圖→傳給 Gemini→讀回答）", g != null, g ?: "沒有答案，請看上面的記錄")
                if (lostApp) log("⚠ 回不到 SolidMemory")
            }
        }
    }

    // 只測 Gemini 這一段：先手動切到練習題畫面（鍵盤開著也行），8 秒後開始。不會作答、不改任何資料
    private fun gemTest() {
        log("Gemini 測試：8 秒後開始，請現在切到 SolidMemory 的練習題畫面（鍵盤開著也行）")
        nap(8000)
        val pk = topPkg()
        if (pk == null) {
            report("讀取目前畫面", false)
            return
        }
        targetPkg = pk
        val items = appNodes()
        val pat = findPattern(items)
        report("讀到題目格式", pat != null, pat ?: "目前畫面不是練習題（最上層 App：${pk}）")
        if (pat == null) return
        val g = askGemini(pat, defChunks(items))
        report("Gemini 判斷", g != null, g ?: "沒有答案，請看上面的記錄")
        if (lostApp) {
            log("⚠ 回不到 SolidMemory")
        } else {
            log("回來後：" + (if (findPattern(appNodes()) != null) "題目還在" else "沒看到題目"))
        }
    }

    private fun doRun(mode: String) {
        log("===== 開始（$mode）=====")
        gestureFails = 0
        targetPkg = null
        if (mode == "diag") {
            diag()
            return
        }
        if (mode == "gem") {
            gemTest()
            return
        }
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val wasLocked = km.isKeyguardLocked
        if (!unlock(km)) {
            log("解鎖失敗，結束")
            return
        }
        val pkg = launchApp() ?: return
        log("已開啟 $pkg")
        for (i in 1..6) {  // 彈窗可能延遲出現，持續檢查幾秒
            nap(1000)
            closePromo()
        }
        log("畫面節點數 ${appNodes().size}")
        if (!clickUntil("詞彙學習", "輸入詞彙", "vocab")) return
        nap(1000)
        if (mode == "test") {
            selfTest()
        } else {
            dailyRun()
        }
        log("===== 結束 =====")
        if (wasLocked) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            nap(800)
            if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }
}
