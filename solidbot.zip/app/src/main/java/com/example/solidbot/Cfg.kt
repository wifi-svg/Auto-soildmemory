package com.example.solidbot

import android.content.Context
import android.content.SharedPreferences
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Cfg {
    private val wordRe = Regex("[a-z][a-z '’-]*")

    fun p(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun str(c: Context, k: String, d: String = ""): String = p(c).getString(k, d) ?: d

    @Synchronized
    fun log(c: Context, m: String) {
        val t = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        p(c).edit().putString("log", ("$t $m\n" + str(c, "log")).take(12000)).apply()
    }

    // 單字或片語，以換行、逗號、分號分隔
    fun wordList(c: Context, key: String): List<String> =
        str(c, key).split(Regex("[\\n,;]+"))
            .map { it.trim().lowercase().replace(Regex("\\s+"), " ") }
            .filter { wordRe.matches(it) }

    fun usedSet(c: Context): Set<String> = wordList(c, "used").toSet()

    @Synchronized
    fun addUsed(c: Context, w: String) {
        p(c).edit().putString("used", str(c, "used").trimEnd() + "\n" + w).apply()
    }
}

// 詞庫：每行「單字<TAB>中文片段|中文片段|…」
object Db {
    private fun f(c: Context, n: String) = File(c.filesDir, n)

    fun load(c: Context, n: String): MutableMap<String, Set<String>> {
        val m = LinkedHashMap<String, Set<String>>()
        val file = f(c, n)
        if (file.exists()) {
            file.forEachLine { l ->
                val i = l.indexOf('\t')
                if (i > 0) m[l.substring(0, i)] = l.substring(i + 1).split('|').filter { it.isNotEmpty() }.toSet()
            }
        }
        return m
    }

    @Synchronized
    fun append(c: Context, n: String, w: String, ch: Set<String>) {
        f(c, n).appendText(w + "\t" + ch.joinToString("|") + "\n")
    }

    // 新詞練習完成後，併入舊詞庫並清空暫存
    @Synchronized
    fun merge(c: Context) {
        val t = f(c, "temp.tsv")
        if (t.exists()) {
            f(c, "db.tsv").appendText(t.readText())
            t.delete()
        }
    }
}
