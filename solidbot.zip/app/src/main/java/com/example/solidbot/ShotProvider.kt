package com.example.solidbot

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

// 把「截圖暫存資料夾」裡的圖片以 content:// 網址交給 Gemini App 讀取（只讀、只有被分享的那一張）
class ShotProvider : ContentProvider() {
    companion object {
        const val AUTH = "com.example.solidbot.shot"
    }

    private fun fileFor(uri: Uri): File? {
        val c = context ?: return null
        val name = uri.lastPathSegment ?: return null
        val dir = File(c.cacheDir, "shots")
        val f = File(dir, name)
        return try {
            if (f.canonicalPath.startsWith(dir.canonicalPath + File.separator) && f.exists()) f else null
        } catch (e: Exception) {
            null
        }
    }

    override fun onCreate(): Boolean = true

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val f = fileFor(uri) ?: return null
        val cur = MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE))
        cur.addRow(arrayOf<Any>(f.name, f.length()))
        return cur
    }

    override fun getType(uri: Uri): String? = "image/jpeg"

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val f = fileFor(uri) ?: throw FileNotFoundException(uri.toString())
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }
}
